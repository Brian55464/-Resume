package com.filmwise.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

fun openGooglePrivacy(context: Context){
    runCatching{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://policies.google.com/privacy")))}
        .onFailure{Toast.makeText(context,"請用瀏覽器開啟 policies.google.com/privacy",Toast.LENGTH_LONG).show()}
}

@Composable fun ArPrivacyDialog(onDismiss:()->Unit,onAccept:()->Unit){
    val context=LocalContext.current
    AlertDialog(onDismissRequest=onDismiss,containerColor=Paper,title={Text("啟用 AR 測距前")},text={
        Column(Modifier.heightIn(max=400.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text("AR 測距使用 Google 提供的 Google Play Services for AR（ARCore），受 Google 隱私權政策規範。服務的資料處理方式請參閱政策，安裝或更新可能需要網路。")
            Text("片刻只使用即時相機與深度資料估算距離，不儲存相機畫面，也未使用雲端場景共享或定位服務。")
            Text("這是選用功能。你可以繼續使用一般測光，或稍後在「隱私與資料」關閉 AR。")
            TextButton(onClick={openGooglePrivacy(context)}){Text("查看 Google 隱私權政策 ↗")}
        }
    },confirmButton={TextButton(onClick=onAccept){Text("同意並啟用")}},
        dismissButton={TextButton(onClick=onDismiss){Text("先用一般測光")}})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PrivacySheet(model: FilmwiseModel,onArDisabled:()->Unit){
    var deletion by remember{mutableIntStateOf(0)}
    val context=LocalContext.current
    ModalBottomSheet(onDismissRequest={model.showPrivacy=false},containerColor=Paper,
        sheetState=rememberModalBottomSheetState(skipPartiallyExpanded=true)){
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=24.dp).padding(bottom=24.dp),
            verticalArrangement=Arrangement.spacedBy(14.dp)){
            PageTitle("隱私與資料","讓你知道鏡頭怎麼用，資料留在哪裡。")
            WarmNote("只在拍攝時使用相機","相機畫面用來即時測光與估距，不拍照存檔、不錄影。離開拍攝、開啟教學或此頁、切到背景時，相機會暫停。拒絕相機權限仍可使用示範與外部輸入。")
            Text("相機名稱、底片規格、校正與最近 30 次比較保存在這個 App 的私人儲存空間。片刻沒有帳號、廣告、追蹤分析或自建伺服器，也未要求網路、定位、麥克風與相簿權限。")
            Hint("已停用系統雲端備份與換機資料搬移。移除 App 或清除全部資料後，無法在 App 內還原。")
            SectionLabel("AR 測距・選用")
            Text("Google Play Services for AR 由 Google 提供並受 Google 隱私權政策規範；服務的安裝、更新與自身資料處理由 Google 管理。片刻未使用雲端場景共享或定位服務。")
            TextButton(onClick={openGooglePrivacy(context)}){Text("Google 隱私權政策 ↗")}
            if(model.arPrivacyAccepted)OutlinedButton(onClick={model.revokeArPrivacy();onArDisabled()}){Text("關閉 AR 並撤回同意")}
            else Hint("目前尚未同意啟用 AR；一般測光不受影響。")
            HorizontalDivider(color=Border)
            SectionLabel("管理這台手機上的資料")
            OutlinedButton(onClick={deletion=1},enabled=model.history.isNotEmpty(),modifier=Modifier.fillMaxWidth()){
                Text("清除拍攝紀錄（"+model.history.size+" 筆）")
            }
            OutlinedButton(onClick={deletion=2},modifier=Modifier.fillMaxWidth()){
                Text("清除全部本機資料")
            }
            ModelError(model)
            Hint("資料使用手機本身的保護機制。請避免在名稱中填入密碼或個資；取得解鎖手機、Root 或除錯權限的人仍可能讀取資料。")
            PrimaryAction("回到 App"){model.showPrivacy=false}
        }
    }
    if(deletion!=0)AlertDialog(onDismissRequest={deletion=0},containerColor=Paper,
        title={Text(if(deletion==1)"清除所有拍攝紀錄？" else "清除全部本機資料？")},
        text={Text(if(deletion==1)"會刪除已儲存的前後比較與其中的相機快照，保留目前的相機和校正。此動作無法復原。"
            else "會刪除所有相機、底片設定、拍攝紀錄、校正與 AR 同意。相機權限仍可到 Android 設定管理。此動作無法復原。")},
        confirmButton={TextButton(onClick={
            if(deletion==1)model.clearHistory() else if(model.clearAllData())onArDisabled()
            deletion=0
        }){Text("確認清除")}},dismissButton={TextButton(onClick={deletion=0}){Text("保留資料")}})
}

