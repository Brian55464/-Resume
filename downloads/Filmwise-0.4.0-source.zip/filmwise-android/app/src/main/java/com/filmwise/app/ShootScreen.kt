package com.filmwise.app

import android.content.Intent as AndroidIntent
import android.net.Uri
import android.provider.Settings
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.filmwise.core.ExposureEngine as E

@Composable
fun CameraGlyph(modifier: Modifier=Modifier,color: Color=Coffee){
    Canvas(modifier.size(38.dp)){
        val w=size.width;val h=size.height
        drawRoundRect(color,Offset(w*.08f,h*.28f),Size(w*.84f,h*.53f),CornerRadius(w*.09f),style=Stroke(w*.045f))
        drawRoundRect(color,Offset(w*.22f,h*.17f),Size(w*.28f,h*.16f),CornerRadius(w*.04f))
        drawCircle(color,w*.15f,Offset(w*.51f,h*.54f),style=Stroke(w*.045f))
        drawCircle(color,w*.035f,Offset(w*.79f,h*.41f))
    }
}
@Composable
fun ActiveCameraCard(model: FilmwiseModel){
    Surface(onClick={model.showCameraPicker=true},color=Sand,shape=RoundedCornerShape(20.dp)){
        Row(Modifier.fillMaxWidth().padding(17.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(13.dp)){
            CameraGlyph()
            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)){
                Hint(if(model.usesQuickMeter)"隨手測一束光" else "今天帶的是")
                Text(if(model.usesQuickMeter)"直接測光・不必新增相機" else model.activeCamera?.profile?.name?:"選擇我的相機",style=MaterialTheme.typography.titleMedium)
                if(model.usesQuickMeter)Hint(referenceIsoLabel(model.quickISO))
                else model.activeCamera?.let{Hint(isoLabel(it.filmISO)+"  ·  "+it.filmName.ifBlank{kindLabel(it.profile.kind)})}
            }
            Icon(Icons.Default.KeyboardArrowDown,"切換測光方式或相機",tint=Coffee)
        }
    }
}
@Composable
fun MeasurementPanel(model: FilmwiseModel,permission: Boolean,arReady: Boolean,cameraActive: Boolean,now: Long,
                     requestPermission:()->Unit,enableAR:()->Unit){
    val context=LocalContext.current
    var advanced by remember{mutableStateOf(false)}
    var explanation by remember{mutableStateOf(false)}
    if(explanation)MeasurementHelpDialog{explanation=false}
    val live=model.mode==MeterMode.PHONE
    val distance=model.distance.takeIf{it.fresh(maxOf(now,SystemClock.elapsedRealtime()))}
    Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
        Box(Modifier.fillMaxWidth().aspectRatio(1.2f).clip(RoundedCornerShape(24.dp)).background(Color(0xFF615044))){
            if(live&&permission&&!cameraActive){
                CenterPreviewText("相機已暫停","回到拍攝畫面後繼續")
            }else if(live&&permission){
                if(model.arPreferred&&arReady&&model.arPrivacyAccepted)ArCameraMeter(
                    onSample={model.sample=it},onCamera={model.cameraChanged(it)},
                    onDistance={model.distance=it},onTap={x,y->model.tapTarget(x,y)},
                    onUnavailable={model.arFailed(it)},modifier=Modifier.fillMaxSize())
                else if(!model.arPreferred)CameraMeter(
                    onSample={model.sample=it},onCamera={model.cameraChanged(it)},
                    onDistance={model.distance=it},onTap={x,y->model.tapTarget(x,y)},modifier=Modifier.fillMaxSize())
                else CenterPreviewText("正在準備自動測距…","請保持手機穩定")
            }else if(live){
                Column(Modifier.align(Alignment.Center).padding(25.dp),horizontalAlignment=Alignment.CenterHorizontally,
                    verticalArrangement=Arrangement.spacedBy(14.dp)){
                    CameraGlyph(color=Color(0xFFF4EADB))
                    Text("讓手機看看現場的光",color=Color.White)
                    Button(onClick=requestPermission){Text("開啟相機權限")}
                    TextButton(onClick={model.changeMode(MeterMode.DEMO)}){
                        Text("先用示範數值試操作",color=Color.White)
                    }
                }
            }else if(model.mode==MeterMode.DEMO)DemoScenePreview()
            else CenterPreviewText("使用你的測光表讀值","不會使用鏡頭測光或測距")
            if(live&&permission){
                Surface(Modifier.align(Alignment.TopStart).padding(14.dp),color=Paper.copy(alpha=.92f),shape=RoundedCornerShape(50)){
                    Text(if(model.arPreferred)"自動測距" else "點選主體對焦",Modifier.padding(horizontal=12.dp,vertical=7.dp),
                        style=MaterialTheme.typography.labelSmall)
                }
                model.target?.let{FocusTarget(it,model.focusTapId)}
                Surface(Modifier.align(Alignment.BottomCenter).padding(14.dp),color=Ink.copy(alpha=.78f),shape=RoundedCornerShape(50)){
                    Text(if(distance!=null)"主體距離約 "+E.one(distance.meters)+" 公尺" else "輕點你想拍的主體",
                        Modifier.padding(horizontal=14.dp,vertical=9.dp),color=Color.White,style=MaterialTheme.typography.labelMedium)
                }
            }
        }
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
            Column{
                Hint(if(live)"手機估算 · EV 100" else if(model.mode==MeterMode.DEMO)"示範數值 · EV 100" else "外部輸入 · EV 100")
                Text(when(model.mode){
                    MeterMode.PHONE->if(model.sample.fresh(maxOf(now,SystemClock.elapsedRealtime())))E.one(model.sample.ev100!!+model.calibration) else "—"
                    MeterMode.DEMO->E.one(model.demoEV)
                    MeterMode.EXTERNAL->model.externalEV
                },style=MaterialTheme.typography.headlineMedium)
            }
            Column(horizontalAlignment=Alignment.End){
                Hint("主體距離")
                Text(if(distance==null)"尚未取得" else "約 "+E.one(distance.meters)+" 公尺",
                    style=MaterialTheme.typography.titleMedium)
            }
        }
        if(model.usesQuickMeter&&model.screen==Screen.SHOOT){
            ReferenceISOSelector(model)
            Hint("不知道 ISO 也能測光；曝光組合先用參考值試算，拍攝前再確認底片盒。")
        }
        if(live){
            Hint(if(distance!=null)distance.source+"・移動後請重新點選" else if(model.distance.meters!=null)"距離已過期，請重新點選主體" else model.distance.message)
            if(permission){
                Text("AR 測距使用 Google Play Services for AR，受 Google 隱私權政策規範。查看政策 ↗",
                    style=MaterialTheme.typography.bodySmall,color=Coffee,
                    modifier=Modifier.clickable{openGooglePrivacy(context)})
                if(!model.arPreferred)OutlinedButton(onClick=enableAR,modifier=Modifier.fillMaxWidth()){
                    Text("啟用 AR 點選測距")
                }
            }
            model.arStatus?.let{Hint(it)}
            Hint(model.sample.status)
        }else Hint("這個模式不會估算距離，仍可先練習查看建議與前後比較。")
        TextButton(onClick={explanation=true}){Text("測光與估距怎麼判讀？")}
        TextButton(onClick={advanced=!advanced}){Text(if(advanced)"收起進階設定" else "進階與電腦測試")}
        if(advanced){
            QuickSelect("讀值來源",model.mode,MeterMode.values().toList(),{
                when(it){MeterMode.PHONE->"手機相機";MeterMode.EXTERNAL->"外部測光表";MeterMode.DEMO->"電腦示範"}
            },{if(it!=null)model.changeMode(it)},allowUnknown=false)
            when(model.mode){
                MeterMode.DEMO->QuickSelect("示範光線",model.demoEV,listOf(4.0,7.0,9.0,10.0,11.0,12.0,14.0,15.0),
                    {E.one(it)+" EV"},{if(it!=null)model.demoEV=it},allowUnknown=false)
                MeterMode.EXTERNAL->OutlinedTextField(value=model.externalEV,onValueChange={model.externalEV=it.take(32)},
                    label={Text("測光表的 EV 100")},singleLine=true,modifier=Modifier.fillMaxWidth(),
                    keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                MeterMode.PHONE->{
                    QuickSelect("測光校正",model.calibration,listOf(-2.0,-1.5,-1.0,-.5,0.0,.5,1.0,1.5,2.0),
                        {E.one(it)+" EV"},{if(it!=null)model.calibrate(it)},allowUnknown=false)
                    Hint("初次先維持 0；與可信的測光表比較後，再調整校正。")
                    if(model.arPreferred)TextButton(onClick={model.useAR(false)}){Text("改用一般對焦預覽")}
                    TextButton(onClick={context.startActivity(AndroidIntent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+context.packageName)))}){
                        Text("相機權限設定")
                    }
                }
            }
        }
    }
}
@Composable private fun BoxScope.CenterPreviewText(title: String,subtitle: String){
    Column(Modifier.align(Alignment.Center).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,
        verticalArrangement=Arrangement.spacedBy(13.dp)){
        CameraGlyph(color=Color(0xFFE9D3B8))
        Text(title,color=Color.White,style=MaterialTheme.typography.titleMedium)
        Text(subtitle,color=Color(0xFFE9D3B8),style=MaterialTheme.typography.bodySmall)
    }
}
fun isoLabel(iso: Int?)=if(iso==null)"ISO 未知" else "ISO "+iso
fun apertureLabel(value: Double?)=value?.let{"f/"+E.one(it)}?:"光圈未知"
fun shutterLabel(value: Double?)=value?.let{E.shutter(it)}?:"快門未知"





