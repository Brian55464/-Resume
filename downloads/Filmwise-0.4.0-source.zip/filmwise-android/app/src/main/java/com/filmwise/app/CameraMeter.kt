package com.filmwise.app

import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.filmwise.core.DistanceEstimate
import com.filmwise.core.MeterEstimator
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

private data class FocusFrame(val diopters: Float?,val state: Int?,val at: Long)

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
@Composable
fun CameraMeter(onSample: (MeterEstimator.Sample)->Unit,onCamera: (String)->Unit,
                onDistance: (DistanceEstimate)->Unit,onTap: (Float,Float)->Unit,modifier: Modifier=Modifier) {
    val context=LocalContext.current
    val owner=LocalLifecycleOwner.current
    val sampleCallback=rememberUpdatedState(onSample)
    val cameraCallback=rememberUpdatedState(onCamera)
    val distanceCallback=rememberUpdatedState(onDistance)
    val tapCallback=rememberUpdatedState(onTap)
    val view=remember(context){PreviewView(context).apply {
        implementationMode=PreviewView.ImplementationMode.COMPATIBLE
        scaleType=PreviewView.ScaleType.FILL_CENTER
        contentDescription="點選主體，對焦並估算距離"
    }}
    DisposableEffect(owner,view) {
        var disposed=false
        var provider: ProcessCameraProvider?=null
        var preview: Preview?=null
        var camera: Camera?=null
        var lensCalibration: Int?=null
        val main=Handler(Looper.getMainLooper())
        val estimator=MeterEstimator()
        val lastMeter=AtomicLong(0)
        val latestFocus=AtomicReference<FocusFrame?>(null)
        val lastTap=AtomicLong(0)
        sampleCallback.value(MeterEstimator.Sample(null,"正在開啟相機",0))
        view.setOnTouchListener { _,event ->
            if(event.action!=MotionEvent.ACTION_UP) return@setOnTouchListener true
            view.performClick()
            val c=camera?:return@setOnTouchListener true
            val tapAt=SystemClock.elapsedRealtime()
            lastTap.set(tapAt)
            tapCallback.value(event.x/view.width.coerceAtLeast(1),event.y/view.height.coerceAtLeast(1))
            val point=view.meteringPointFactory.createPoint(event.x,event.y)
            val action=FocusMeteringAction.Builder(point,FocusMeteringAction.FLAG_AF)
                .setAutoCancelDuration(5,TimeUnit.SECONDS).build()
            val future=c.cameraControl.startFocusAndMetering(action)
            future.addListener({
                if(!disposed&&lastTap.get()==tapAt) {
                    val focused=runCatching{future.get().isFocusSuccessful}.getOrDefault(false)
                    fun collect(attempt: Int) {
                        if(disposed||lastTap.get()!=tapAt)return
                        val f=latestFocus.get()
                        val now=SystemClock.elapsedRealtime()
                        val focusReady=f!=null&&f.at>=tapAt&&now-f.at<800&&
                            (f.state==CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED||
                             f.state==CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED)
                        val meters=if(focusReady)DistanceEstimate.fromFocus(f?.diopters,lensCalibration,focused)else null
                        if(meters!=null)distanceCallback.value(DistanceEstimate(meters,"鏡頭對焦估算","距離為近似值",now))
                        else if(attempt<3&&focused)main.postDelayed({collect(attempt+1)},180)
                        else distanceCallback.value(DistanceEstimate.unknown(
                            "這個鏡頭暫時沒有可靠距離，可啟用 AR 測距；仍可取得光線建議"))
                    }
                    collect(0)
                }
            },ContextCompat.getMainExecutor(context))
            true
        }
        val future=ProcessCameraProvider.getInstance(context)
        future.addListener({
            if(!disposed)try {
                val p=future.get();provider=p
                val builder=Preview.Builder()
                Camera2Interop.Extender(builder)
                    .setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON)
                    .setCaptureRequestOption(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION,0)
                    .setCaptureRequestOption(CaptureRequest.FLASH_MODE,CaptureRequest.FLASH_MODE_OFF)
                    .setSessionCaptureCallback(object: CameraCaptureSession.CaptureCallback(){
                        override fun onCaptureCompleted(session: CameraCaptureSession,request: CaptureRequest,result: TotalCaptureResult){
                            val now=SystemClock.elapsedRealtime()
                            latestFocus.set(FocusFrame(result.get(CaptureResult.LENS_FOCUS_DISTANCE),
                                result.get(CaptureResult.CONTROL_AF_STATE),now))
                            val last=lastMeter.get()
                            if(now-last<180||!lastMeter.compareAndSet(last,now))return
                            val s=estimator.accept(result.get(CaptureResult.SENSOR_EXPOSURE_TIME),
                                result.get(CaptureResult.SENSOR_SENSITIVITY),result.get(CaptureResult.LENS_APERTURE),
                                result.get(CaptureResult.CONTROL_POST_RAW_SENSITIVITY_BOOST),
                                result.get(CaptureResult.CONTROL_AE_STATE),now)
                            main.post{if(!disposed)sampleCallback.value(s)}
                        }
                    })
                val useCase=builder.build().also{it.setSurfaceProvider(view.surfaceProvider)}
                preview=useCase
                camera=p.bindToLifecycle(owner,CameraSelector.DEFAULT_BACK_CAMERA,useCase)
                val info=Camera2CameraInfo.from(camera!!.cameraInfo)
                lensCalibration=info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_FOCUS_DISTANCE_CALIBRATION)
                cameraCallback.value("focus:"+info.cameraId)
            }catch(e: Exception){
                sampleCallback.value(MeterEstimator.Sample(null,"相機暫時無法開啟，請檢查權限或稍後重試",0))
            }
        },ContextCompat.getMainExecutor(context))
        onDispose {
            disposed=true;view.setOnTouchListener(null)
            preview?.let{provider?.unbind(it)}
            main.removeCallbacksAndMessages(null)
        }
    }
    AndroidView(factory={view},modifier=modifier)
}
