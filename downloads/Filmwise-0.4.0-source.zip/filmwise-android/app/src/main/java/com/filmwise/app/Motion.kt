package com.filmwise.app

import android.animation.ValueAnimator
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

/** Enter only: the outgoing camera composition is disposed immediately, never crossfaded. */
@Composable fun GentleEntrance(modifier: Modifier=Modifier,content:@Composable ()->Unit){
    val enabled=ValueAnimator.areAnimatorsEnabled()
    val progress=remember{Animatable(if(enabled)0f else 1f)}
    val distance=with(LocalDensity.current){7.dp.toPx()}
    LaunchedEffect(enabled){if(enabled)progress.animateTo(1f,tween(190))else progress.snapTo(1f)}
    Box(modifier.graphicsLayer{alpha=progress.value;translationY=(1-progress.value)*distance}){content()}
}

@Composable fun FocusTarget(target: Offset,tapId: Long){
    val enabled=ValueAnimator.areAnimatorsEnabled()
    val scale=remember{Animatable(1f)}
    LaunchedEffect(tapId,enabled){
        if(enabled){scale.snapTo(1.18f);scale.animateTo(1f,tween(180))}else scale.snapTo(1f)
    }
    Canvas(Modifier.fillMaxSize()){
        val edge=44.dp.toPx()*scale.value
        val x=(target.x*size.width-edge/2).coerceIn(0f,(size.width-edge).coerceAtLeast(0f))
        val y=(target.y*size.height-edge/2).coerceIn(0f,(size.height-edge).coerceAtLeast(0f))
        val color=Color(0xFFF8DFC0)
        drawRoundRect(color,Offset(x,y),Size(edge,edge),CornerRadius(9.dp.toPx()),style=Stroke(2.dp.toPx()))
        drawCircle(color,2.dp.toPx(),Offset(x+edge/2,y+edge/2))
    }
}
