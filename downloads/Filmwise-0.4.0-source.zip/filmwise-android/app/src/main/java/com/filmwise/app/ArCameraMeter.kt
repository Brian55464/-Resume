package com.filmwise.app

import android.content.Context
import android.graphics.PointF
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.filmwise.core.CameraFrameGate
import com.filmwise.core.DistanceEstimate
import com.filmwise.core.MeterEstimator
import com.google.ar.core.Config
import com.google.ar.core.Coordinates2d
import com.google.ar.core.DepthPoint
import com.google.ar.core.ImageMetadata
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** The AR session owns the camera exclusively; CameraX is disposed before this view is bound. */
@Composable
fun ArCameraMeter(onSample:(MeterEstimator.Sample)->Unit,onCamera:(String)->Unit,
                  onDistance:(DistanceEstimate)->Unit,onTap:(Float,Float)->Unit,
                  onUnavailable:(String)->Unit,modifier: Modifier=Modifier) {
    val context=LocalContext.current
    val owner=LocalLifecycleOwner.current
    val cbSample=rememberUpdatedState(onSample)
    val cbCamera=rememberUpdatedState(onCamera)
    val cbDistance=rememberUpdatedState(onDistance)
    val cbTap=rememberUpdatedState(onTap)
    val cbUnavailable=rememberUpdatedState(onUnavailable)
    val view=remember(context){ArMeterSurface(context,
        {cbSample.value(it)},{cbDistance.value(it)},{x,y->cbTap.value(x,y)})}
    DisposableEffect(owner,view) {
        val main=Handler(Looper.getMainLooper())
        var disposed=false
        var session: Session?=null
        var running=false
        fun pause(){
            if(running){view.active=false;view.onPause();runCatching{session?.pause()};running=false}
        }
        fun resume(attempt: Int=0){
            if(disposed||running||!owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))return
            try {
                session?.resume()?:return
                view.active=true;view.onResume();running=true
            }catch(e: CameraNotAvailableException){
                if(attempt<3)main.postDelayed({resume(attempt+1)},350)
                else cbUnavailable.value("鏡頭暫時忙碌，已改用一般預覽，可稍後再啟用自動測距")
            }catch(e: Exception){cbUnavailable.value("自動測距暫時不可用，已保留一般拍攝建議")}
        }
        val observer=LifecycleEventObserver {_,event->
            if(event==Lifecycle.Event.ON_RESUME)resume()
            if(event==Lifecycle.Event.ON_PAUSE)pause()
        }
        try {
            val s=Session(context);session=s
            if(!s.isDepthModeSupported(Config.DepthMode.AUTOMATIC)){
                s.close();session=null;main.post{if(!disposed)cbUnavailable.value("此裝置目前不支援 AR 深度，已改用一般預覽")}
            }else{
                val config=Config(s).apply {
                    depthMode=Config.DepthMode.AUTOMATIC
                    cloudAnchorMode=Config.CloudAnchorMode.DISABLED
                    geospatialMode=Config.GeospatialMode.DISABLED
                    focusMode=Config.FocusMode.AUTO
                    lightEstimationMode=Config.LightEstimationMode.DISABLED
                    planeFindingMode=Config.PlaneFindingMode.DISABLED
                    updateMode=Config.UpdateMode.LATEST_CAMERA_IMAGE
                }
                s.configure(config);session=s;view.session=s
                cbCamera.value("ar:"+s.cameraConfig.cameraId)
                cbSample.value(MeterEstimator.Sample(null,"請慢慢左右移動手機，再點選主體",0))
                owner.lifecycle.addObserver(observer);resume()
            }
         }catch(e: Exception){
            runCatching{session?.close()};session=null;view.session=null
            main.post{if(!disposed)cbUnavailable.value("自動測距尚未準備好，仍可使用一般預覽")}
        }
        onDispose{
            disposed=true;owner.lifecycle.removeObserver(observer);pause()
            view.release();session?.close();main.removeCallbacksAndMessages(null)
        }
    }
    AndroidView(factory={view},modifier=modifier)
}

private data class SelectedPoint(val point: PointF,val id: Long)

private class ArMeterSurface(
    context: Context,
    private val onSample:(MeterEstimator.Sample)->Unit,
    private val onDistance:(DistanceEstimate)->Unit,
    private val onTap:(Float,Float)->Unit
): GLSurfaceView(context),GLSurfaceView.Renderer {
    @Volatile var session: Session?=null
    @Volatile var active=false
    @Volatile private var alive=true
    private val main=Handler(Looper.getMainLooper())
    private val tap=AtomicReference<SelectedPoint?>(null)
    private val tapId=AtomicLong(0)
    private val estimator=MeterEstimator()
    private val frameGate=CameraFrameGate()
    private var lastTracking: TrackingState?=null
    private var meterAt=0L
    private var texture=0
    private var program=0
    private var textureBound=false
    private var widthPx=1
    private var heightPx=1
    private val vertices=buffer(floatArrayOf(-1f,-1f,1f,-1f,-1f,1f,1f,1f))
    private val uv=buffer(FloatArray(8))
    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause=true
        setRenderer(this)
        contentDescription="點選主體，以 AR 深度估算距離"
        setOnTouchListener {_,event->
            if(event.action==MotionEvent.ACTION_UP){
                performClick()
                onTap(event.x/width.coerceAtLeast(1),event.y/height.coerceAtLeast(1))
                tap.set(SelectedPoint(PointF(event.x,event.y),tapId.incrementAndGet()))
            }
            true
        }
    }
    fun release(){alive=false;active=false;main.removeCallbacksAndMessages(null)}
    override fun onSurfaceCreated(gl: GL10?,config: EGLConfig?){
        val ids=IntArray(1);GLES20.glGenTextures(1,ids,0);texture=ids[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE)
        val v=shader(GLES20.GL_VERTEX_SHADER,"attribute vec4 a_Position; attribute vec2 a_TexCoord; varying vec2 v_UV; void main(){gl_Position=a_Position;v_UV=a_TexCoord;}")
        val f=shader(GLES20.GL_FRAGMENT_SHADER,"#extension GL_OES_EGL_image_external : require\nprecision mediump float; uniform samplerExternalOES u_Texture; varying vec2 v_UV; void main(){gl_FragColor=texture2D(u_Texture,v_UV);}")
        program=GLES20.glCreateProgram();GLES20.glAttachShader(program,v);GLES20.glAttachShader(program,f)
        GLES20.glLinkProgram(program)
        GLES20.glDeleteShader(v);GLES20.glDeleteShader(f)
        textureBound=false
    }
    override fun onSurfaceChanged(gl: GL10?,width: Int,height: Int){
        widthPx=width;heightPx=height;GLES20.glViewport(0,0,width,height)
    }
    override fun onDrawFrame(gl: GL10?){
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val s=session?:return
        if(!active||!alive||program==0)return
        try{
            if(!textureBound){s.setCameraTextureName(texture);textureBound=true}
            s.setDisplayGeometry(display?.rotation?:Surface.ROTATION_0,widthPx,heightPx)
            val frame=s.update()
            vertices.position(0);uv.position(0)
            frame.transformCoordinates2d(Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,vertices,
                Coordinates2d.TEXTURE_NORMALIZED,uv)
            GLES20.glDisable(GLES20.GL_DEPTH_TEST)
            GLES20.glUseProgram(program);GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(program,"u_Texture"),0)
            val pos=GLES20.glGetAttribLocation(program,"a_Position")
            val tex=GLES20.glGetAttribLocation(program,"a_TexCoord")
            vertices.position(0);uv.position(0)
            GLES20.glEnableVertexAttribArray(pos);GLES20.glEnableVertexAttribArray(tex)
            GLES20.glVertexAttribPointer(pos,2,GLES20.GL_FLOAT,false,0,vertices)
            GLES20.glVertexAttribPointer(tex,2,GLES20.GL_FLOAT,false,0,uv)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4)
            GLES20.glDisableVertexAttribArray(pos);GLES20.glDisableVertexAttribArray(tex)
            val now=SystemClock.elapsedRealtime()
            frameGate.observe(frame.timestamp,now)
            if(lastTracking==TrackingState.TRACKING&&frame.camera.trackingState!=TrackingState.TRACKING){
                main.post{if(alive&&active)onDistance(DistanceEstimate.unknown("追蹤暫時中斷，請重新點選主體"))}
            }
            lastTracking=frame.camera.trackingState
            if(now-meterAt>=180&&frameGate.takeSample(now)){
                meterAt=now
                val meta=runCatching{frame.imageMetadata}.getOrNull()
                val sample=estimator.accept(
                    runCatching{meta?.getLong(ImageMetadata.SENSOR_EXPOSURE_TIME)}.getOrNull(),
                    runCatching{meta?.getInt(ImageMetadata.SENSOR_SENSITIVITY)}.getOrNull(),
                    runCatching{meta?.getFloat(ImageMetadata.LENS_APERTURE)}.getOrNull(),
                    runCatching{meta?.getInt(ImageMetadata.CONTROL_POST_RAW_SENSITIVITY_BOOST)}.getOrNull(),
                    runCatching{meta?.getByte(ImageMetadata.CONTROL_AE_STATE)?.toInt()?.and(255)}.getOrNull(),now)
                main.post{if(alive&&active)onSample(sample)}
            }
            val point=tap.getAndSet(null)
            if(point!=null){
                val hit=if(frameGate.fresh(now)&&frame.camera.trackingState==TrackingState.TRACKING)
                    frame.hitTest(point.point.x,point.point.y).firstOrNull {
                        it.trackable is DepthPoint&&it.trackable.trackingState==TrackingState.TRACKING&&
                            it.distance.isFinite()&&it.distance in .2f..15f
                    } else null
                val estimate=if(hit!=null)DistanceEstimate(hit.distance.toDouble(),"AR 深度估算","距離為近似值",now)
                    else DistanceEstimate.unknown("這個位置暫無有效深度，請緩慢移動手機後再點選")
                main.post{if(alive&&active&&tapId.get()==point.id)onDistance(estimate)}
            }
        }catch(e: Exception){
            val now=SystemClock.elapsedRealtime()
            if(now-meterAt>1200){
                meterAt=now
                main.post{if(alive&&active)onSample(MeterEstimator.Sample(null,"請保持光線穩定，稍後再試",0))}
            }
        }
    }
    private fun shader(type: Int,code: String): Int {
        val id=GLES20.glCreateShader(type);GLES20.glShaderSource(id,code);GLES20.glCompileShader(id);return id
    }
    companion object{
        private fun buffer(values: FloatArray): FloatBuffer =
            ByteBuffer.allocateDirect(values.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(values);position(0)}
    }
}


