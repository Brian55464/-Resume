package com.filmwise.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.filmwise.core.QuickExposure
import com.filmwise.core.ExposureEngine as E
import com.filmwise.core.ExposureEngine.Intent
import com.filmwise.core.ExposureEngine.Reading

fun referenceIsoLabel(iso: Int?)=if(iso==null)"ISO 未知・暫以 400 試算" else "以 ISO "+iso+" 試算"
fun needsReference(reading: Reading)=QuickExposure.isQuick(reading)||reading.iso==null||
    (reading.profile.aperture==null&&reading.profile.shutter==null&&E.bestPair(reading)==null)

@Composable fun ReferenceISOSelector(model: FilmwiseModel){
    QuickSelect("試算底片 ISO",model.quickISO,listOf(100,200,400,800,1600,50,125,160,3200),
        {it.toString()},model::setReferenceISO,unknownText="不知道・先以 ISO 400 試算")
}

@Composable fun ReferenceExposureCard(ev100: Double,iso: Int?,intent: Intent,compact: Boolean=false){
    val options=remember(ev100,iso,intent){QuickExposure.suggest(ev100,iso,intent)}
    Surface(color=Sand,shape=RoundedCornerShape(21.dp)){
        Column(Modifier.fillMaxWidth().padding(if(compact)14.dp else 18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
                FieldIcon("光圈")
                Text("可以參考的曝光組合",style=MaterialTheme.typography.titleMedium)
            }
            Text(referenceIsoLabel(iso),style=MaterialTheme.typography.bodySmall,color=Coffee)
            if(options.isEmpty())Text("光線超出這組常見刻度的試算範圍，請確認讀值、增加光線或使用適合的器材。")
            options.take(if(compact)1 else 3).forEach{option->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                    Text("f/"+E.one(option.aperture),style=MaterialTheme.typography.titleMedium)
                    Text(E.shutter(option.shutter),style=MaterialTheme.typography.titleMedium)
                }
            }
            if(!compact&&options.any{it.slow})Hint(if(intent==Intent.MOVING)"部分快門較慢，主體移動可能模糊，可考慮增加光線。" else "部分快門較慢，請留意手持晃動或使用穩固支撐。")
            if(!compact)Hint("以上是通用試算。先確認底片 ISO，再依相機實際可用的光圈、快門選擇；傻瓜機可能無法手動調整。")
        }
    }
}

@Composable fun QuickReadingCard(reading: Reading){
    if(QuickExposure.isQuick(reading)&&!reading.flash){
        WarmNote("這裡約 EV "+E.one(reading.ev100),
            if(reading.ev100<8)"現場光線較弱，可以靠近窗邊、增加照明，或使用穩固支撐。" else "先參考下方曝光組合，再依你想留下的氣氛選擇。")
        Hint(reading.source+"・EV 100・"+referenceIsoLabel(reading.iso))
    }else{
        val a=E.assess(reading)
        WarmNote(a.title,a.detail)
        Hint(reading.profile.name+" · "+isoLabel(reading.iso)+" · "+apertureLabel(a.actualAperture)+" · "+shutterLabel(a.actualShutter))
        Hint(reading.source+" / EV "+E.one(reading.ev100)+" / "+(reading.distance?.let{"約 "+E.one(it)+" 公尺"}?:"距離未知"))
    }
    if(needsReference(reading))ReferenceExposureCard(reading.ev100,reading.iso,reading.intent)
}

@Composable fun EverydayScene(modifier: Modifier=Modifier){
    Image(painterResource(R.drawable.tutorial_daily_scene),
        contentDescription="窗邊木桌上的咖啡杯、筆記本與綠色盆栽・日常場景示範照片",
        contentScale=ContentScale.Crop,modifier=modifier)
}

@Composable fun DemoScenePreview(){
    Box(Modifier.fillMaxSize()){
        EverydayScene(Modifier.fillMaxSize())
        Surface(Modifier.align(Alignment.TopStart).padding(12.dp),color=Paper.copy(alpha=.95f),shape=RoundedCornerShape(50)){
            Text("日常場景示範",Modifier.padding(horizontal=12.dp,vertical=7.dp),style=MaterialTheme.typography.labelSmall,color=Coffee)
        }
        Surface(Modifier.align(Alignment.BottomCenter).padding(12.dp),color=Ink.copy(alpha=.86f),shape=RoundedCornerShape(15.dp)){
            Text("示範數值・非現場測光",Modifier.padding(horizontal=14.dp,vertical=9.dp),color=Paper,style=MaterialTheme.typography.labelMedium)
        }
    }
}
