package com.filmwise.app

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.*
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.filmwise.core.MeterEstimator
import com.google.ar.core.ArCoreApk
import kotlinx.coroutines.delay

val Paper=Color(0xFFFAF6EF)
val Ink=Color(0xFF3E3027)
val Coffee=Color(0xFF84614C)
val Sand=Color(0xFFEFE3D5)
val Border=Color(0xFFE3D7C9)

class MainActivity: ComponentActivity(){
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        if(Build.VERSION.SDK_INT>=33)setRecentsScreenshotEnabled(false)
        if(Build.VERSION.SDK_INT>=31)splashScreen.setOnExitAnimationListener{view->
            if(ValueAnimator.areAnimatorsEnabled())view.animate().alpha(0f).setDuration(180).withEndAction{view.remove()}.start()
            else view.remove()
        }
        enableEdgeToEdge(statusBarStyle=SystemBarStyle.light(0,0),navigationBarStyle=SystemBarStyle.light(0,0))
        setContent {
            val type=filmwiseTypography()
            MaterialTheme(colorScheme=lightColorScheme(primary=Coffee,onPrimary=Color.White,
                primaryContainer=Sand,onPrimaryContainer=Ink,background=Paper,onBackground=Ink,
                surface=Paper,onSurface=Ink,surfaceVariant=Sand,onSurfaceVariant=Color(0xFF7B6B60),
                outline=Color(0xFFAC9683),outlineVariant=Border,secondary=Coffee,secondaryContainer=Sand,
                onSecondaryContainer=Ink,error=Color(0xFF985543),errorContainer=Color(0xFFF4E3D7),onErrorContainer=Ink),
                typography=type,
                shapes=Shapes(medium=RoundedCornerShape(18.dp),large=RoundedCornerShape(24.dp))){FilmwiseApp()}
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilmwiseApp(model: FilmwiseModel=viewModel()){
    val context=LocalContext.current
    val owner=LocalLifecycleOwner.current
    var permission by remember{mutableStateOf(ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)}
    var clockTick by remember{mutableLongStateOf(SystemClock.elapsedRealtime())}
    var arReady by remember{mutableStateOf(false)}
    var resumed by remember{mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))}
    var showArNotice by remember{mutableStateOf(false)}
    var enableArAfterPermission by remember{mutableStateOf(false)}
    val permissionRequest=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){permission=it}
    fun prepareAR(requested: Boolean){
        if(!model.arPrivacyAccepted||!permission||!owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))return
        try {
            when(ArCoreApk.getInstance().requestInstall(context as Activity,requested)){
                ArCoreApk.InstallStatus.INSTALLED->{
                    model.arInstallPending=false;model.arStatus=null
                    if(!model.arPreferred)model.useAR(true)
                    arReady=true
                }
                ArCoreApk.InstallStatus.INSTALL_REQUESTED->{model.arInstallPending=true;arReady=false}
            }
        }catch(e: Exception){
            model.arInstallPending=false;arReady=false
            model.arFailed("自動測距尚未準備好，仍可點選對焦與取得拍攝建議。")
        }
    }
    fun enableAR(){
        if(!model.arPrivacyAccepted){showArNotice=true;return}
        if(!permission){enableArAfterPermission=true;permissionRequest.launch(Manifest.permission.CAMERA);return}
        ArCoreApk.getInstance().checkAvailabilityAsync(context){availability->
            if(model.arPrivacyAccepted&&owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)){
                if(availability.isSupported)prepareAR(true)
                else model.arStatus="這台裝置目前無法啟用 AR 深度，仍可使用一般對焦與測光。"
            }
        }
    }
    LaunchedEffect(permission){
        if(enableArAfterPermission){
            enableArAfterPermission=false
            if(permission)enableAR()
        }
    }
    DisposableEffect(owner){
        val observer=LifecycleEventObserver{_,event->
            if(event==Lifecycle.Event.ON_RESUME){
                resumed=true
                permission=ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED
                if(permission&&(model.arPreferred||model.arInstallPending))prepareAR(false)
            }
            if(event==Lifecycle.Event.ON_PAUSE){resumed=false;model.clearDistance();model.sample=MeterEstimator.Sample(null,"等待重新測光",0)}
        }
        owner.lifecycle.addObserver(observer)
        onDispose{owner.lifecycle.removeObserver(observer)}
    }
    LaunchedEffect(owner){owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED){
        while(true){clockTick=SystemClock.elapsedRealtime();delay(300)}
    }}
    LaunchedEffect(permission){if(permission&&model.arPreferred)prepareAR(false)}
    // A frame may arrive after the timer tick; compare it with the actual current time.
    val now=SystemClock.elapsedRealtime().coerceAtLeast(clockTick)
    val cameraActive=resumed&&!model.showTutorial&&!model.showPrivacy&&!model.showCameraPicker&&!model.showAdvice&&!model.showReferenceISO&&!showArNotice
    LaunchedEffect(cameraActive){
        if(!cameraActive){model.clearDistance();model.sample=MeterEstimator.Sample(null,"相機已暫停",0)}
    }
    BackHandler(enabled=model.screen!=Screen.SHOOT){model.back()}
    Scaffold(containerColor=Paper,topBar={
        TopAppBar(title={Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
            Text("片刻",fontFamily=KaiFont,fontWeight=FontWeight.Medium)
            Text("FILMWISE",fontSize=10.sp,letterSpacing=2.sp,color=Coffee)
        }},navigationIcon={if(model.screen!=Screen.SHOOT)IconButton(onClick={model.back()}){Icon(Icons.AutoMirrored.Filled.ArrowBack,"返回")}},
        actions={IconButton(onClick={model.showPrivacy=true}){Icon(Icons.Default.Lock,"隱私與資料",tint=Coffee)}
        IconButton(onClick={model.tutorialPage=0;model.showTutorial=true}){Icon(Icons.Default.Info,"使用教學",tint=Coffee)}},
        colors=TopAppBarDefaults.topAppBarColors(containerColor=Paper))
    },bottomBar={Column {
        if(model.screen==Screen.SHOOT||model.screen==Screen.REMEASURE){
            Box(Modifier.fillMaxWidth().padding(horizontal=22.dp).padding(top=8.dp,bottom=10.dp)){
                val remeasure=model.screen==Screen.REMEASURE
                PrimaryAction(if(remeasure)"重新測量，看看差異" else if(model.usesQuickMeter)"測光並看建議" else "看看這張怎麼拍",model.ready(SystemClock.elapsedRealtime())){model.capture(SystemClock.elapsedRealtime(),remeasure)}
            }
        }
        NavigationBar(containerColor=Paper,tonalElevation=0.dp){
        listOf(Triple(Screen.SHOOT,"拍攝",Icons.Default.Home),Triple(Screen.CAMERAS,"我的相機",Icons.Default.Settings),
            Triple(Screen.HISTORY,"紀錄",Icons.Default.DateRange)).forEach{(screen,label,icon)->
            NavigationBarItem(selected=model.screen==screen,onClick={model.showAdvice=false;model.screen=screen},
                icon={Icon(icon,null)},label={Text(label)})
        }
    }}}){padding->
        key(model.screen){GentleEntrance{Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
            .padding(horizontal=22.dp).padding(top=10.dp,bottom=28.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
            when(model.screen){
                Screen.SHOOT->{
                    PageTitle("把光留在底片裡","對準主體就能測光，相機資料可以之後再加入。")
                    ActiveCameraCard(model)
                    MeasurementPanel(model,permission,arReady,cameraActive,now,{permissionRequest.launch(Manifest.permission.CAMERA)},::enableAR)
                    QuickSelect("這次想拍什麼",model.intent,com.filmwise.core.ExposureEngine.Intent.values().toList(),
                        ::intentLabel,{if(it!=null)model.intent=it},allowUnknown=false)
                    if(model.usesQuickMeter)model.currentEV(maxOf(now,SystemClock.elapsedRealtime()))?.let{ev->
                        GentleEntrance{ReferenceExposureCard(ev,model.quickISO,model.intent)}
                    }
                    ModelError(model)
                }
                Screen.CAMERAS->CamerasScreen(model)
                Screen.EDIT->CameraEditor(model)
                Screen.PLANS->PlansScreen(model)
                Screen.REMEASURE->{
                    PageTitle("調整一下，再看一次","依照建議操作後，重新點選主體並測量。")
                    model.selectedPlan?.let{plan->
                        WarmNote(plan.title,plan.description)
                        if(plan.pair!=null||plan.id=="flash")Row(verticalAlignment=Alignment.CenterVertically){
                            Checkbox(checked=model.actionConfirmed,onCheckedChange={model.confirmAction(it)})
                            Text("我已在底片相機上完成這個調整",style=MaterialTheme.typography.bodyMedium)
                        }
                    }
                    MeasurementPanel(model,permission,arReady,cameraActive,now,{permissionRequest.launch(Manifest.permission.CAMERA)},::enableAR)

                    ModelError(model)
                }
                Screen.COMPARISON->ComparisonScreen(model)
                Screen.HISTORY->HistoryScreen(model)
            }
        }}}
    }
    if(model.showReferenceISO)AlertDialog(onDismissRequest={model.showReferenceISO=false},containerColor=Paper,
        title={Text("選擇試算底片 ISO")},text={
            Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
                Hint("找找底片盒上的數字。不知道時可保留未知，先以 400 作參考。")
                ReferenceISOSelector(model)
            }
        },confirmButton={TextButton(onClick={model.showReferenceISO=false}){Text("完成")}})
    if(model.showPrivacy)PrivacySheet(model){arReady=false}
    if(showArNotice)ArPrivacyDialog(onDismiss={showArNotice=false},onAccept={
        model.acceptArPrivacy();showArNotice=false;enableAR()
    })
    if(model.showTutorial)TutorialSheet(model)
    if(model.showCameraPicker)CameraPickerSheet(model)
    if(model.showAdvice&&!model.showTutorial)AdviceSheet(model)
}
@Composable fun PageTitle(title: String,subtitle: String){
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Medium)
        Hint(subtitle)
    }
}
@Composable fun Hint(text: String){Text(text,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
@Composable fun SectionLabel(text: String){Text(text,style=MaterialTheme.typography.titleSmall,color=Coffee)}
@Composable fun WarmNote(title: String,text: String){
    Surface(shape=RoundedCornerShape(20.dp),color=Sand){
        Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Medium)
            Text(text,style=MaterialTheme.typography.bodyMedium)
        }
    }
}
@Composable fun PrimaryAction(text: String,enabled: Boolean=true,onClick:()->Unit){
    Button(onClick=onClick,enabled=enabled,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp),shape=RoundedCornerShape(18.dp)){Text(text)}
}
@Composable fun ModelError(model: FilmwiseModel){model.error?.let{Text(it,color=MaterialTheme.colorScheme.error)}}
fun intentLabel(intent: com.filmwise.core.ExposureEngine.Intent)=when(intent){
    com.filmwise.core.ExposureEngine.Intent.STILL->"靜物・朋友・日常"
    com.filmwise.core.ExposureEngine.Intent.MOVING->"跑動的人・移動中的主體"
    com.filmwise.core.ExposureEngine.Intent.LANDSCAPE->"風景・街景"
}






