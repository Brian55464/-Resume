package com.filmwise.app

import android.app.Application
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import com.filmwise.core.DistanceEstimate
import com.filmwise.core.ExposureEngine as E
import com.filmwise.core.ExposureEngine.*
import com.filmwise.core.MeterEstimator
import com.filmwise.core.QuickExposure

enum class Screen { SHOOT, CAMERAS, EDIT, PLANS, REMEASURE, COMPARISON, HISTORY }
enum class MeterMode { PHONE, EXTERNAL, DEMO }

class FilmwiseModel(application: Application): AndroidViewModel(application) {
    private val store=SessionStore(application)
    var cameras by mutableStateOf(store.cameras())
    var activeId by mutableStateOf(store.selectedCamera()?.takeIf {id->cameras.any {it.id==id}}?:cameras.firstOrNull()?.id)
    val activeCamera: CameraEntry? get()=cameras.find {it.id==activeId}
    var directMeter by mutableStateOf(store.directMeterPreferred()?:cameras.isEmpty())
    val usesQuickMeter: Boolean get()=directMeter||activeCamera==null
    var quickISO by mutableStateOf(store.quickISO())
    var showReferenceISO by mutableStateOf(false)
    var focusTapId by mutableLongStateOf(0)
    var screen by mutableStateOf(Screen.SHOOT)
    var editingId by mutableStateOf<String?>(null)
    var editorDraft by mutableStateOf<CameraDraft?>(null)
    var intent by mutableStateOf(Intent.STILL)
    var mode by mutableStateOf(MeterMode.PHONE)
    var externalEV by mutableStateOf("7.0")
    var demoEV by mutableStateOf(7.0)
    var calibration by mutableStateOf(0.0)
    var cameraKey by mutableStateOf("")
    var sample by mutableStateOf(MeterEstimator.Sample(null,"等待開啟相機",0))
    var distance by mutableStateOf(DistanceEstimate.unknown("點選畫面中的主體，讓手機估算距離"))
    var target by mutableStateOf<Offset?>(null)
    var before by mutableStateOf<Reading?>(null)
    var after by mutableStateOf<Reading?>(null)
    var selectedPlan by mutableStateOf<Plan?>(null)
    var actionConfirmed by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var history by mutableStateOf(store.history())
    var alreadySaved by mutableStateOf(false)
    var showTutorial by mutableStateOf(!store.tutorialSeen())
    var tutorialPage by mutableIntStateOf(0)
    var showCameraPicker by mutableStateOf(false)
    var showAdvice by mutableStateOf(false)
    var adviceIsAfter by mutableStateOf(false)
    var showPrivacy by mutableStateOf(false)
    var arPrivacyAccepted by mutableStateOf(store.arPrivacyAccepted())
    var arPreferred by mutableStateOf(store.arPreferred()&&arPrivacyAccepted)
    var arInstallPending by mutableStateOf(false)
    var arStatus by mutableStateOf<String?>(null)

    private fun persist(){store.saveCameras(cameras,activeId);store.saveDirectMeter(directMeter)}
    fun useQuickMeter(){directMeter=true;store.saveDirectMeter(true);resetSession();showCameraPicker=false;screen=Screen.SHOOT}
    fun setReferenceISO(value: Int?){
        com.filmwise.core.InputLimits.iso(value)
        showReferenceISO=false
        if(quickISO==value)return
        quickISO=value;store.saveQuickISO(value);resetSession();screen=Screen.SHOOT
    }
    fun currentEV(now: Long): Double?=when(mode){
        MeterMode.PHONE->if(sample.fresh(now))sample.ev100!!+calibration else null
        MeterMode.EXTERNAL->externalEV.toDoubleOrNull()?.takeIf{it.isFinite()&&it in -6.0..24.0}
        MeterMode.DEMO->demoEV
    }
    fun beginEdit(id: String?){editingId=id;editorDraft=cameras.find{it.id==id}?.let{CameraDraft.from(it)}?:CameraDraft();error=null;screen=Screen.EDIT}
    fun saveCamera(entry: CameraEntry){
        if(cameras.none{it.id==entry.id}&&cameras.size>=com.filmwise.core.InputLimits.MAX_CAMERAS){
            error="最多保留 50 台相機，請先刪除不需要的相機。";return
        }
        cameras=if(cameras.any{it.id==entry.id})cameras.map{if(it.id==entry.id)entry else it} else cameras+entry
        activeId=entry.id;directMeter=false;persist();resetSession();screen=Screen.SHOOT
    }
    fun selectCamera(id: String){
        if(cameras.none{it.id==id})return
        activeId=id;directMeter=false;persist();resetSession();showCameraPicker=false;screen=Screen.SHOOT
    }
    fun deleteCamera(id: String){
        cameras=cameras.filterNot{it.id==id}
        if(activeId==id){activeId=cameras.firstOrNull()?.id;resetSession()}
        persist()
    }
    fun resetSession(){
        before=null;after=null;selectedPlan=null;error=null;alreadySaved=false;showAdvice=false;showReferenceISO=false;clearDistance()
    }
    fun clearDistance(){
        distance=DistanceEstimate.unknown("點選畫面中的主體，讓手機估算距離");target=null
    }
    fun tapTarget(x: Float,y: Float){
        focusTapId++;target=Offset(x,y);distance=DistanceEstimate.unknown("正在對焦與估距，請保持片刻")
    }
    fun cameraChanged(id: String){
        if(cameraKey!=id){cameraKey=id;calibration=store.calibration(id);clearDistance()}
    }
    fun calibrate(value: Double){
        if(cameraKey.isBlank()||!value.isFinite())return
        calibration=value.coerceIn(-4.0,4.0);store.saveCalibration(cameraKey,calibration)
    }
    fun changeMode(next: MeterMode){mode=next;error=null;clearDistance()}
    fun useAR(value: Boolean){
        arPreferred=value&&arPrivacyAccepted;store.saveArPreferred(arPreferred);sample=MeterEstimator.Sample(null,"正在切換鏡頭",0);clearDistance()
    }
    fun acceptArPrivacy(){store.acceptArPrivacy();arPrivacyAccepted=true}
    fun revokeArPrivacy(){
        useAR(false);arInstallPending=false;arPrivacyAccepted=false;store.revokeArPrivacy()
    }
    fun clearHistory(){
        if(!store.clearHistory()){error="未能清除紀錄，請稍後再試。";return}
        history=emptyList();resetSession()
        if(screen in listOf(Screen.PLANS,Screen.REMEASURE,Screen.COMPARISON))screen=Screen.HISTORY
    }
    fun clearAllData(): Boolean {
        if(!store.clearAll()){error="未能清除資料，請稍後再試。";return false}
        cameras=emptyList();activeId=null;directMeter=true;quickISO=null;history=emptyList();editingId=null;editorDraft=null
        arPrivacyAccepted=false;arPreferred=false;arInstallPending=false;arStatus=null
        calibration=0.0;cameraKey="";sample=MeterEstimator.Sample(null,"等待開啟相機",0)
        externalEV="7.0";demoEV=7.0;intent=Intent.STILL;mode=MeterMode.PHONE
        showCameraPicker=false;showTutorial=false;screen=Screen.SHOOT;resetSession()
        return true
    }
    fun arFailed(message: String){arStatus=message;useAR(false)}
    fun finishTutorial(){showTutorial=false;store.finishTutorial()}
    fun ready(now: Long): Boolean=when(mode){
        MeterMode.PHONE->cameraKey.isNotBlank()&&sample.fresh(now)
        MeterMode.EXTERNAL->externalEV.toDoubleOrNull()?.let{it.isFinite()&&it in -6.0..24.0}==true
        MeterMode.DEMO->true
    }
    fun capture(now: Long,isAfter: Boolean){
        error=null
        val entry=if(usesQuickMeter)CameraEntry(QuickExposure.profile(),quickISO)else activeCamera?:return
        if(!ready(now)){error="光線讀值尚未穩定，請對準主體保持片刻。";return}
        val ev: Double;val source: String;val signature: String
        when(mode){
            MeterMode.PHONE->{ev=sample.ev100!!+calibration;source="手機光線估算";signature="phone:"+cameraKey+":"+java.lang.Double.toHexString(calibration)}
            MeterMode.EXTERNAL->{ev=externalEV.toDouble();source="外部測光表輸入";signature="external-manual"}
            MeterMode.DEMO->{ev=demoEV;source="示範數值・非實際測光";signature="demo-v2"}
        }
        val d=distance.takeIf{mode==MeterMode.PHONE&&it.fresh(now)}
        if(isAfter){
            val b=before?:return;val plan=selectedPlan?:return
            if((plan.pair!=null||plan.id=="flash")&&!actionConfirmed){error="請先確認已在底片相機上完成操作。";return}
            val r=Reading(entry.profile,b.iso,ev,d?.meters,b.intent,plan.id=="flash",source,signature,
                System.currentTimeMillis(),d?.source?:"尚未取得距離")
            if(!E.comparable(b,r)){error="相機、底片 ISO 或讀值來源已改變，請重新開始這次比較。";return}
            after=r;alreadySaved=false;screen=Screen.COMPARISON;adviceIsAfter=true
        }else{
            before=Reading(entry.profile,entry.filmISO,ev,d?.meters,intent,false,source,signature,
                System.currentTimeMillis(),d?.source?:"尚未取得距離")
            after=null;selectedPlan=null;alreadySaved=false;screen=Screen.PLANS;adviceIsAfter=false
        }
        showAdvice=true
    }
    fun choose(plan: Plan){
        if(plan.id=="film-info"){
            resetSession()
            if(usesQuickMeter){screen=Screen.SHOOT;showReferenceISO=true}
            else activeCamera?.let{beginEdit(it.id)}
            return
        }
        selectedPlan=plan;actionConfirmed=false;error=null;showAdvice=false;clearDistance();screen=Screen.REMEASURE
    }
    fun confirmAction(value: Boolean){
        actionConfirmed=value
        val plan=selectedPlan
        val entry=activeCamera
        if(value&&plan?.pair!=null&&entry!=null){
            val updated=entry.copy(profile=entry.profile.withSettings(plan.pair.aperture,plan.pair.shutter))
            cameras=cameras.map{if(it.id==entry.id)updated else it};persist()
        }
    }
    fun saveComparison(){
        if(alreadySaved)return
        val b=before?:return;val a=after?:return;val p=selectedPlan?:return
        history=(listOf(SavedComparison(b,a,p.title))+history).take(30)
        store.saveHistory(history);alreadySaved=true;screen=Screen.HISTORY
    }
    fun openHistory(item: SavedComparison){
        before=item.before;after=item.after;selectedPlan=null;alreadySaved=true;error=null;screen=Screen.COMPARISON
    }
    fun back(){
        showAdvice=false;error=null
        screen=when(screen){
            Screen.SHOOT->Screen.SHOOT
            Screen.CAMERAS,Screen.HISTORY->Screen.SHOOT
            Screen.EDIT->Screen.CAMERAS
            Screen.PLANS->Screen.SHOOT
            Screen.REMEASURE->Screen.PLANS
            Screen.COMPARISON->if(selectedPlan!=null)Screen.REMEASURE else Screen.HISTORY
        }
    }
}


