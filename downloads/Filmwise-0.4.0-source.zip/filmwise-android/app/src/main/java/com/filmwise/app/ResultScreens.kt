package com.filmwise.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.filmwise.core.ExposureEngine as E
import com.filmwise.core.ExposureEngine.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable fun CamerasScreen(model: FilmwiseModel){
    var deleting by remember{mutableStateOf<CameraEntry?>(null)}
    PageTitle("我的相機櫃","儲存常用相機，或直接開始測光。")
    OutlinedButton(onClick={model.useQuickMeter()},modifier=Modifier.fillMaxWidth()){Text("直接測光・不必新增相機")}
    PrimaryAction("＋ 新增相機"){model.beginEdit(null)}
    if(model.cameras.isEmpty())WarmNote("想記住相機時，再加入","直接測光已經能使用。儲存相機後，才能依實際器材限制提供更適合的建議。")
    model.cameras.forEach{entry->
        Surface(shape=RoundedCornerShape(20.dp),color=if(entry.id==model.activeId&&!model.usesQuickMeter)Sand else Paper,
            border=BorderStroke(1.dp,Border)){
            Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){
                    CameraGlyph()
                    Column(Modifier.weight(1f)){
                        Text(entry.profile.name,style=MaterialTheme.typography.titleMedium)
                        Hint(kindLabel(entry.profile.kind))
                    }
                    if(entry.id==model.activeId&&!model.usesQuickMeter)Icon(Icons.Default.Check,"目前使用",tint=Coffee)
                }
                Hint(isoLabel(entry.filmISO)+" · "+entry.filmName.ifBlank{"底片名稱未填"})
                Hint(apertureLabel(entry.profile.aperture)+" · "+shutterLabel(entry.profile.shutter))
                Row(verticalAlignment=Alignment.CenterVertically){
                    TextButton(onClick={model.selectCamera(entry.id)},modifier=Modifier.weight(1f)){
                        Text(if(entry.id==model.activeId&&!model.usesQuickMeter)"帶這台去拍攝" else "使用這台")
                    }
                    IconButton(onClick={model.beginEdit(entry.id)}){Icon(Icons.Default.Edit,"編輯 "+entry.profile.name)}
                    IconButton(onClick={deleting=entry}){Icon(Icons.Default.Delete,"刪除 "+entry.profile.name)}
                }
            }
        }
    }
    deleting?.let{entry->AlertDialog(onDismissRequest={deleting=null},title={Text("刪除「"+entry.profile.name+"」？")},
        text={Text("這台相機會從相機櫃移除，已儲存的拍攝紀錄仍會保留。")},
        confirmButton={TextButton(onClick={model.deleteCamera(entry.id);deleting=null}){Text("刪除相機")}},
        dismissButton={TextButton(onClick={deleting=null}){Text("取消")}})}
}
@Composable fun PlansScreen(model: FilmwiseModel){
    val reading=model.before?:return
    PageTitle("留給這一刻的建議","選一個你願意嘗試的調整，再量一次看看。")
    AssessmentCard(reading)
    E.plans(reading).forEach{plan->PlanCard(plan){model.choose(plan)}}
}
@Composable fun AssessmentCard(reading: Reading){
    QuickReadingCard(reading)
}
@Composable fun PlanCard(plan: Plan,onClick:()->Unit){
    Surface(onClick=onClick,shape=RoundedCornerShape(19.dp),color=Paper,border=BorderStroke(1.dp,Border)){
        Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
                FieldIcon(plan.title)
                Text(plan.title,style=MaterialTheme.typography.titleMedium,modifier=Modifier.weight(1f))
            }
            Hint(plan.description)
            Text("試試這個方式 →",style=MaterialTheme.typography.labelMedium,color=Coffee)
        }
    }
}
@Composable fun ComparisonScreen(model: FilmwiseModel){
    val before=model.before?:return;val after=model.after?:return
    PageTitle("這次有什麼改變","光線數值是參考，最後仍要看你想留下的畫面。")
    Surface(color=Sand,shape=RoundedCornerShape(22.dp)){
        Row(Modifier.fillMaxWidth().padding(20.dp),horizontalArrangement=Arrangement.SpaceBetween){
            Column{Hint("調整前 EV");Text(E.one(before.ev100),style=MaterialTheme.typography.headlineMedium)}
            Column{Hint("調整後 EV");Text(E.one(after.ev100),style=MaterialTheme.typography.headlineMedium)}
        }
    }
    val comparable=E.comparable(before,after)
    val change=after.ev100-before.ev100
    WarmNote(if(comparable)"現場光線"+(if(change>=0)"增加 " else "減少 ")+E.one(kotlin.math.abs(change))+" 格" else "這兩筆讀值無法直接比較",
        if(after.flash)"閃光的瞬間亮度無法由這次環境測光驗證，請另外確認閃光範圍與相機設定。"
        else "EV 只顯示現場光線變化，不能單靠數字判定照片一定變好。光圈或快門的調整請參考下方評估。")
    AssessmentCard(after)
    if(!model.alreadySaved&&model.selectedPlan!=null)PrimaryAction("把這次比較存起來"){model.saveComparison()}
    PrimaryAction("開始下一張"){model.resetSession();model.screen=Screen.SHOOT}
}
@Composable fun HistoryScreen(model: FilmwiseModel){
    PageTitle("拍攝小記","記下嘗試過的方式，下次拍攝多一點把握。")
    if(model.history.isNotEmpty())TextButton(onClick={model.showPrivacy=true}){Text("管理與清除紀錄")}
    if(model.history.isEmpty())WarmNote("還沒有紀錄","完成一次建議與重新測量後，就能儲存在這裡。")
    model.history.forEach{item->
        Surface(onClick={model.openHistory(item)},shape=RoundedCornerShape(19.dp),color=Sand){
            Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Hint(SimpleDateFormat("MM.dd  HH:mm",Locale.TAIWAN).format(Date(item.after.timeMillis)))
                Text(item.before.profile.name,style=MaterialTheme.typography.titleMedium)
                Text(item.planTitle,style=MaterialTheme.typography.bodyMedium)
                Hint(E.one(item.before.ev100)+" → "+E.one(item.after.ev100)+" EV · "+item.after.source)
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun CameraPickerSheet(model: FilmwiseModel){
    ModalBottomSheet(onDismissRequest={model.showCameraPicker=false},containerColor=Paper,
        sheetState=rememberModalBottomSheetState(skipPartiallyExpanded=true)){
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=24.dp).padding(bottom=24.dp),
            verticalArrangement=Arrangement.spacedBy(16.dp)){
            PageTitle("這次怎麼測光？","直接量光線，或使用已儲存的相機。")
            Surface(onClick={model.useQuickMeter()},color=if(model.usesQuickMeter)Sand else Paper,
                shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Border)){
                Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){
                    FieldIcon("光線")
                    Column(Modifier.weight(1f)){Text("直接測光");Hint("相機、快門與光圈都可以不知道")}
                    if(model.usesQuickMeter)Icon(Icons.Default.Check,"目前使用直接測光")
                }
            }
            model.cameras.forEach{entry->
                Surface(onClick={model.selectCamera(entry.id)},color=if(entry.id==model.activeId&&!model.usesQuickMeter)Sand else Paper,
                    shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Border)){
                    Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically,
                        horizontalArrangement=Arrangement.spacedBy(12.dp)){
                        CameraGlyph()
                        Column(Modifier.weight(1f)){Text(entry.profile.name);Hint(isoLabel(entry.filmISO))}
                        if(entry.id==model.activeId&&!model.usesQuickMeter)Icon(Icons.Default.Check,"目前使用")
                    }
                }
            }
            PrimaryAction("＋ 新增相機"){model.showCameraPicker=false;model.beginEdit(null)}
            TextButton(onClick={model.showCameraPicker=false;model.screen=Screen.CAMERAS}){Text("管理我的相機")}
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AdviceSheet(model: FilmwiseModel){
    val reading=(if(model.adviceIsAfter)model.after else model.before)?:return
    ModalBottomSheet(onDismissRequest={model.showAdvice=false},containerColor=Paper,
        sheetState=rememberModalBottomSheetState(skipPartiallyExpanded=true)){
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=24.dp).padding(bottom=28.dp),
            verticalArrangement=Arrangement.spacedBy(16.dp)){
            SectionLabel(if(model.adviceIsAfter)"調整後的小提醒" else "給這一張的小提醒")
            AssessmentCard(reading)
            if(!model.adviceIsAfter)E.plans(reading).take(3).forEach{plan->PlanCard(plan){model.choose(plan)}}
            PrimaryAction(if(model.adviceIsAfter)"查看前後比較" else "查看所有建議"){model.showAdvice=false}
        }
    }
}


