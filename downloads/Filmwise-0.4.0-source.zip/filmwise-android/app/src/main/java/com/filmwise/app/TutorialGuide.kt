package com.filmwise.app

import android.animation.ValueAnimator
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.filmwise.core.QuickExposure
import com.filmwise.core.ExposureEngine as E
import com.filmwise.core.ExposureEngine.Intent

private data class GuidePage(val title: String,val description: String,val practice: String)

@Composable private fun GuideExample(step: Int,iso: Int,onISO:(Int)->Unit,onEnlarge:()->Unit){
    Surface(color=Sand,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Border)){
        Column(Modifier.fillMaxWidth().heightIn(min=290.dp).padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Box(Modifier.fillMaxWidth().height(145.dp).clip(RoundedCornerShape(15.dp)).clickable(onClick=onEnlarge)){
                EverydayScene(Modifier.fillMaxSize())
                Surface(color=Paper.copy(alpha=.96f),shape=RoundedCornerShape(25.dp),modifier=Modifier.align(Alignment.BottomEnd).padding(8.dp)){
                    Row(Modifier.padding(horizontal=9.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.Search,null,Modifier.size(15.dp),tint=Coffee)
                        Text(" 放大照片",style=MaterialTheme.typography.labelSmall,color=Coffee)
                    }
                }
            }
            when(step){
                0->{
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                        Column{Hint("示範光線 · EV 100");Text("9.0",style=MaterialTheme.typography.headlineSmall)}
                        Column(horizontalAlignment=Alignment.End){Hint("不知道底片 ISO");Text("先以 400 試算",style=MaterialTheme.typography.titleSmall)}
                    }
                    Text("f/2.8  ·  1/250 秒  ·  通用參考",style=MaterialTheme.typography.bodySmall,color=Coffee)
                }
                1->{
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
                        listOf(100,400).forEach{value->FilterChip(selected=iso==value,onClick={onISO(value)},label={Text("ISO "+value)})}
                    }
                    val option=QuickExposure.suggest(9.0,iso,Intent.STILL).first{it.aperture==4.0}
                    Text("同樣 EV 9.0：f/4.0  ·  "+E.shutter(option.shutter),style=MaterialTheme.typography.titleSmall)
                }
                2->{
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                        Column{Hint("原位置・示範");Text("EV 7.0",style=MaterialTheme.typography.titleMedium)}
                        Text("→",color=Coffee)
                        Column{Hint("靠近窗邊・示範");Text("EV 9.0",style=MaterialTheme.typography.titleMedium)}
                    }
                    Text("重新測量，確認光線變化。",style=MaterialTheme.typography.bodySmall,color=Coffee)
                }
                else->{
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){
                        CameraGlyph(Modifier.size(30.dp))
                        Column{Text("旅行用傻瓜機・範例",style=MaterialTheme.typography.titleSmall);Hint("ISO 400・其他規格可留空")}
                    }
                    Hint("儲存常用相機是選用功能。")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TutorialSheet(model: FilmwiseModel){
    val pages=listOf(
        GuidePage("先測光，不必新增相機","打開拍攝頁，對準主體。讀值穩定後，直接查看光線與光圈、快門參考；點一下畫面可對焦與嘗試估距。","試試直接測光"),
        GuidePage("ISO 不知道，也能先試算","光線可以直接測量。曝光組合需要 ISO；未知時先用 400 作參考。點下方 100 或 400，看看同樣光線下的快門如何改變。","到拍攝頁選 ISO"),
        GuidePage("調整位置，再量一次","把主體移到窗邊，或增加照明，再重新測光比較。所有組合都要確認相機可用刻度；傻瓜相機可能無法手動調整。","測量這一刻的光"),
        GuidePage("有常用相機，再加入","想保存底片、鏡頭與相機限制時，再到「我的相機」新增。知道多少填多少，日後可切換，也可繼續使用直接測光。","看看我的相機")
    )
    val index=model.tutorialPage.coerceIn(0,pages.lastIndex)
    val page=pages[index]
    var enlarged by remember{mutableStateOf(false)}
    var licenses by remember{mutableStateOf(false)}
    var explanation by remember{mutableStateOf(false)}
    var exampleISO by remember{mutableIntStateOf(400)}
    val duration=if(ValueAnimator.areAnimatorsEnabled())160 else 0
    ModalBottomSheet(onDismissRequest={model.finishTutorial()},containerColor=Paper,
        sheetState=rememberModalBottomSheetState(skipPartiallyExpanded=true)){
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=24.dp).padding(bottom=22.dp),
            verticalArrangement=Arrangement.spacedBy(13.dp)){
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
                SectionLabel("拍攝小指南  "+(index+1)+" / "+pages.size)
                TextButton(onClick={model.finishTutorial()}){Text("稍後再看")}
            }
            Crossfade(index,animationSpec=tween(duration),label="教學範例切換"){step->
                GuideExample(step,exampleISO,{exampleISO=it}){enlarged=true}
            }
            Hint("日常場景示範・數字僅供教學，非照片的實際測光結果")
            PageTitle(page.title,page.description)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                pages.indices.forEach{n->Surface(color=if(n==index)Coffee else Border,shape=RoundedCornerShape(50),
                    modifier=Modifier.width(if(n==index)28.dp else 8.dp).height(7.dp)){} }
            }
            PrimaryAction(if(index==pages.lastIndex)"開始我的拍攝" else "下一步"){
                if(index==pages.lastIndex)model.finishTutorial()else model.tutorialPage++
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                TextButton(onClick={model.tutorialPage--},enabled=index>0){Text("上一步")}
                TextButton(onClick={
                    model.finishTutorial()
                    if(index==3)model.screen=Screen.CAMERAS else model.useQuickMeter()
                }){Text(page.practice+" →")}
            }
            HorizontalDivider(color=Border)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                TextButton(onClick={explanation=true}){Text("測光與估距說明",style=MaterialTheme.typography.labelMedium)}
                TextButton(onClick={licenses=true}){Text("字型與授權",style=MaterialTheme.typography.labelMedium)}
            }
        }
    }
    if(enlarged)Dialog(onDismissRequest={enlarged=false}){
        Surface(color=Paper,shape=RoundedCornerShape(20.dp)){
            Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                EverydayScene(Modifier.fillMaxWidth().aspectRatio(1.1f).clip(RoundedCornerShape(14.dp)))
                Text("窗邊咖啡桌・日常場景範例",style=MaterialTheme.typography.titleMedium)
                Hint("照片為教學示意素材，曝光數字不代表這張照片的實測結果。")
                TextButton(onClick={enlarged=false},modifier=Modifier.align(Alignment.End)){Text("回到教學")}
            }
        }
    }
    if(licenses)FontLicenseDialog{licenses=false}
    if(explanation)MeasurementHelpDialog{explanation=false}
}

@Composable fun MeasurementHelpDialog(onDismiss:()->Unit){
    AlertDialog(onDismissRequest=onDismiss,containerColor=Paper,title={Text("測光與距離，怎麼判讀？")},text={
        Column(Modifier.heightIn(max=440.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(15.dp)){
            HelpParagraph("手機測光","依手機相機的曝光資料換算光線參考。讀值穩定代表資料連續，不代表已通過精準度校正；請先與可信測光表在相同構圖下對照。")
            HelpParagraph("底片 ISO","選擇底片盒上的 ISO。一卷底片通常沿用同一個值。手機自己的感光度只用於換算光線，不會取代你的底片 ISO。")
            HelpParagraph("點選主體","一般預覽中的點選用於對焦與估距；光線仍是整體畫面的參考，並非精準的局部點測光。")
            HelpParagraph("自動估距","鏡頭對焦資料或 AR 深度都屬近似值。對焦失敗、追蹤中斷、無有效資料或距離過期時，請重新點選；不會以猜測值填補未知距離。")
            HelpParagraph("閃光建議","閃光距離依已知 GN、ISO 與光圈估算，適用直打模型；手機無法驗證另一台底片相機實際閃光的瞬間亮度。")
            HelpParagraph("目前驗證範圍","曝光計算與模擬器操作已檢查。三星 A57 的現場測光偏差及估距準確度仍需實機對照，暫不宣稱已達專業測光表精度。")
        }
    },confirmButton={TextButton(onClick=onDismiss){Text("知道了")}})
}
@Composable private fun HelpParagraph(title: String,body: String){
    Column(verticalArrangement=Arrangement.spacedBy(5.dp)){
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
            FieldIcon(title,Modifier.size(19.dp))
            Text(title,style=MaterialTheme.typography.titleSmall,color=Coffee)
        }
        Text(body,style=MaterialTheme.typography.bodyMedium)
    }
}
@Composable fun FontLicenseDialog(onDismiss:()->Unit){
    val context=LocalContext.current
    val license=remember(context){context.resources.openRawResource(R.raw.font_license).bufferedReader().use{it.readText()}}
    AlertDialog(onDismissRequest=onDismiss,containerColor=Paper,title={Text("全字庫正楷體與授權")},text={
        Column(Modifier.heightIn(max=420.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text("介面使用全字庫正楷體 TW-Kai，字型來源為數位發展部 CNS11643。")
            Text(license,style=MaterialTheme.typography.bodySmall)
        }
    },confirmButton={TextButton(onClick=onDismiss){Text("關閉")}})
}
