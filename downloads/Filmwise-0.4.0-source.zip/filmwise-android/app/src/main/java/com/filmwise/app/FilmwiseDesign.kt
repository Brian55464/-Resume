package com.filmwise.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

val KaiFont=FontFamily(Font(R.font.cns_kai))
val MenuCream=Color(0xFFF2E6D7)
val FieldCream=Color(0xFFF6EDE2)

fun filmwiseTypography(): Typography {
    val t=Typography()
    return Typography(
        displayLarge=t.displayLarge.copy(fontFamily=KaiFont),
        displayMedium=t.displayMedium.copy(fontFamily=KaiFont),
        displaySmall=t.displaySmall.copy(fontFamily=KaiFont),
        headlineLarge=t.headlineLarge.copy(fontFamily=KaiFont),
        headlineMedium=t.headlineMedium.copy(fontFamily=KaiFont),
        headlineSmall=t.headlineSmall.copy(fontFamily=KaiFont),
        titleLarge=t.titleLarge.copy(fontFamily=KaiFont),
        titleMedium=t.titleMedium.copy(fontFamily=KaiFont),
        titleSmall=t.titleSmall.copy(fontFamily=KaiFont),
        bodyLarge=t.bodyLarge.copy(fontFamily=KaiFont,fontSize=17.sp,lineHeight=26.sp),
        bodyMedium=t.bodyMedium.copy(fontFamily=KaiFont,fontSize=16.sp,lineHeight=24.sp),
        bodySmall=t.bodySmall.copy(fontFamily=KaiFont,fontSize=14.sp,lineHeight=21.sp),
        labelLarge=t.labelLarge.copy(fontFamily=KaiFont,fontSize=16.sp,lineHeight=22.sp),
        labelMedium=t.labelMedium.copy(fontFamily=KaiFont,fontSize=14.sp,lineHeight=20.sp),
        labelSmall=t.labelSmall.copy(fontFamily=KaiFont,fontSize=12.sp,lineHeight=18.sp)
    )
}

@Composable
fun warmFieldColors()=OutlinedTextFieldDefaults.colors(
    focusedContainerColor=FieldCream,unfocusedContainerColor=FieldCream,
    disabledContainerColor=FieldCream,focusedBorderColor=Coffee,
    unfocusedBorderColor=Border,focusedLabelColor=Coffee,
    unfocusedLabelColor=Coffee,focusedLeadingIconColor=Coffee,
    unfocusedLeadingIconColor=Coffee,focusedTrailingIconColor=Coffee,
    unfocusedTrailingIconColor=Coffee,focusedTextColor=Ink,unfocusedTextColor=Ink
)

/** Small line drawings remain crisp without a separate bitmap or emoji font. */
@Composable
fun FieldIcon(label: String,modifier: Modifier=Modifier,color: Color=Coffee){
    val kind=when{
        label.contains("ISO")->"iso"
        label.contains("光圈")->"aperture"
        label.contains("快門")->"shutter"
        label.contains("閃光")->"flash"
        label.contains("對焦")||label.contains("距離")||label.contains("焦距")->"focus"
        label.contains("相機")->"camera"
        label.contains("底片")->"film"
        label.contains("光線")||label.contains("測光")->"sun"
        label.contains("紀錄")->"note"
        else->"settings"
    }
    Canvas(modifier.size(22.dp)){
        scale(size.width/24f,size.height/24f,pivot=Offset.Zero){
            val stroke=Stroke(1.55f,cap=StrokeCap.Round)
            fun line(x: Float,y: Float,xx: Float,yy: Float)=
                drawLine(color,Offset(x,y),Offset(xx,yy),1.55f,StrokeCap.Round)
            when(kind){
                "camera"->{
                    drawRoundRect(color,Offset(2f,6f),Size(20f,15f),CornerRadius(3f),style=stroke)
                    drawCircle(color,4.2f,Offset(12f,13.5f),style=stroke)
                    line(6f,6f,8f,3f);line(8f,3f,14f,3f);line(14f,3f,16f,6f)
                    drawCircle(color,1f,Offset(19f,9f))
                }
                "film","iso"->{
                    drawRoundRect(color,Offset(3f,3f),Size(18f,18f),CornerRadius(2f),style=stroke)
                    listOf(6f,12f,18f).forEach {y->
                        drawCircle(color,.8f,Offset(6f,y));drawCircle(color,.8f,Offset(18f,y))
                    }
                    if(kind=="iso"){
                        line(9f,14f,9f,10f);line(12f,16f,12f,8f);line(15f,13f,15f,11f)
                    }else drawRoundRect(color,Offset(9f,7f),Size(6f,10f),CornerRadius(1f),style=stroke)
                }
                "aperture"->{
                    drawCircle(color,9f,Offset(12f,12f),style=stroke)
                    val points=(0..5).map {n->
                        val a=(n*60.0-90)*Math.PI/180
                        Offset(12f+4.3f*cos(a).toFloat(),12f+4.3f*sin(a).toFloat())
                    }
                    val p=Path().apply{moveTo(points[0].x,points[0].y);points.drop(1).forEach{lineTo(it.x,it.y)};close()}
                    drawPath(p,color,style=stroke)
                    points.forEachIndexed{i,v->
                        val a=(i*60.0-25)*Math.PI/180
                        line(v.x,v.y,12f+9f*cos(a).toFloat(),12f+9f*sin(a).toFloat())
                    }
                }
                "shutter"->{
                    drawCircle(color,8.5f,Offset(12f,13f),style=stroke)
                    line(9f,2f,15f,2f);line(12f,2f,12f,4f)
                    line(12f,13f,12f,8f);line(12f,13f,16f,15f)
                }
                "flash"->{
                    val p=Path().apply{moveTo(14f,2f);lineTo(5f,14f);lineTo(11f,14f);lineTo(10f,22f);lineTo(20f,9f);lineTo(13f,9f);close()}
                    drawPath(p,color,style=stroke)
                }
                "focus"->{
                    line(3f,8f,3f,3f);line(3f,3f,8f,3f)
                    line(16f,3f,21f,3f);line(21f,3f,21f,8f)
                    line(21f,16f,21f,21f);line(21f,21f,16f,21f)
                    line(8f,21f,3f,21f);line(3f,21f,3f,16f)
                    drawCircle(color,3.5f,Offset(12f,12f),style=stroke)
                }
                "sun"->{
                    drawCircle(color,4f,Offset(12f,12f),style=stroke)
                    (0..7).forEach{i->val a=i*Math.PI/4
                        line(12f+7f*cos(a).toFloat(),12f+7f*sin(a).toFloat(),
                            12f+10f*cos(a).toFloat(),12f+10f*sin(a).toFloat())}
                }
                "note"->{
                    drawRoundRect(color,Offset(5f,3f),Size(15f,18f),CornerRadius(2f),style=stroke)
                    line(9f,8f,16f,8f);line(9f,12f,16f,12f);line(9f,16f,13f,16f)
                }
                else->{
                    line(3f,6f,21f,6f);line(3f,12f,21f,12f);line(3f,18f,21f,18f)
                    drawCircle(FieldCream,2.3f,Offset(8f,6f));drawCircle(color,2.3f,Offset(8f,6f),style=stroke)
                    drawCircle(FieldCream,2.3f,Offset(16f,12f));drawCircle(color,2.3f,Offset(16f,12f),style=stroke)
                    drawCircle(FieldCream,2.3f,Offset(10f,18f));drawCircle(color,2.3f,Offset(10f,18f),style=stroke)
                }
            }
        }
    }
}

