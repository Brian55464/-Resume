package com.filmwise.app

import android.content.Context
import com.filmwise.core.ExposureEngine.*
import com.filmwise.core.InputLimits as Limits
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class CameraEntry(val profile: Profile,val filmISO: Int?,val filmName: String="") {
    init { Limits.iso(filmISO);Limits.text(filmName,120,"底片名稱") }
    val id: String get()=profile.id
}
data class SavedComparison(val before: Reading,val after: Reading,val planTitle: String,
                           val savedAt: Long=System.currentTimeMillis()) {
    init { Limits.text(planTitle,160,"建議名稱");require(savedAt>=0) }
}

/** Only small metadata is persisted, in app-private storage; never camera frames. */
class SessionStore(context: Context) {
    private val prefs=context.getSharedPreferences("filmwise-v1",Context.MODE_PRIVATE)
    init {
        if(!prefs.contains("camerasV2")) {
            val legacy=runCatching {
                if(!prefs.getBoolean("profileConfirmed",false)) return@runCatching null
                val raw=bounded("profile",null)?:return@runCatching null
                val p=profileFromJson(JSONObject(raw),UUID.randomUUID().toString())
                CameraEntry(p,prefs.getInt("filmISO",400),prefs.getString("filmName","")?:"")
            }.getOrNull()
            saveCameras(listOfNotNull(legacy),legacy?.id)
        }
    }
    private fun bounded(key: String,fallback: String?): String? {
        val value=prefs.getString(key,fallback)?:return null
        require(value.length<=Limits.MAX_JSON)
        return value
    }
    fun cameras(): List<CameraEntry> = runCatching {
        val array=JSONArray(bounded("camerasV2","[]"))
        (0 until minOf(array.length(),Limits.MAX_CAMERAS)).mapNotNull { i ->
            runCatching {
                val item=array.getJSONObject(i)
                CameraEntry(profileFromJson(item.getJSONObject("profile")),integer(item,"filmISO"),
                    text(item,"filmName",120,""))
            }.getOrNull()
        }.distinctBy{it.id}
    }.getOrElse{emptyList()}
    fun selectedCamera()=runCatching{prefs.getString("selectedCameraV2",null)?.takeIf{it.length<=200}}.getOrNull()
    fun saveCameras(entries: List<CameraEntry>,selected: String?) {
        require(entries.size<=Limits.MAX_CAMERAS)
        val array=JSONArray()
        entries.forEach {e->array.put(JSONObject().put("profile",profileJson(e.profile))
            .put("filmISO",e.filmISO?:JSONObject.NULL).put("filmName",e.filmName))}
        val encoded=array.toString();require(encoded.length<=Limits.MAX_JSON)
        prefs.edit().putString("camerasV2",encoded).apply{
            if(selected==null)remove("selectedCameraV2")else putString("selectedCameraV2",selected)
        }.apply()
    }
    private fun flag(key: String)=runCatching{prefs.getBoolean(key,false)}.getOrDefault(false)
    fun tutorialSeen()=flag("tutorialSeenV4")
    fun finishTutorial(){prefs.edit().putBoolean("tutorialSeenV4",true).apply()}
    fun directMeterPreferred(): Boolean?=if(prefs.contains("directMeterV1"))flag("directMeterV1")else null
    fun saveDirectMeter(value: Boolean){prefs.edit().putBoolean("directMeterV1",value).apply()}
    fun quickISO(): Int?=runCatching{prefs.getInt("quickISOV1",0).takeIf{it in 1..1000000}}.getOrNull()
    fun saveQuickISO(value: Int?){
        Limits.iso(value)
        prefs.edit().apply{if(value==null)remove("quickISOV1")else putInt("quickISOV1",value)}.apply()
    }
    fun arPreferred()=flag("arPreferredV2")
    fun saveArPreferred(value: Boolean){prefs.edit().putBoolean("arPreferredV2",value).apply()}
    fun arPrivacyAccepted()=flag("arPrivacyAcceptedV1")
    fun acceptArPrivacy(){prefs.edit().putBoolean("arPrivacyAcceptedV1",true).apply()}
    fun revokeArPrivacy(){prefs.edit().remove("arPrivacyAcceptedV1").putBoolean("arPreferredV2",false).apply()}
    fun calibration(camera: String)=runCatching{
        prefs.getFloat("calibration."+camera,0f).toDouble().takeIf{it.isFinite()&&it in -4.0..4.0}?:0.0
    }.getOrDefault(0.0)
    fun saveCalibration(camera: String,value: Double){
        require(value.isFinite()&&value in -4.0..4.0)
        prefs.edit().putFloat("calibration."+camera,value.toFloat()).apply()
    }
    fun history(): List<SavedComparison> = runCatching {
        val array=JSONArray(bounded("history","[]"))
        (0 until minOf(array.length(),Limits.MAX_HISTORY)).mapNotNull{i->runCatching{
            val item=array.getJSONObject(i)
            SavedComparison(readingFromJson(item.getJSONObject("before")),
                readingFromJson(item.getJSONObject("after")),text(item,"plan",160),item.getLong("savedAt"))
        }.getOrNull()}
    }.getOrElse{emptyList()}
    fun saveHistory(items: List<SavedComparison>) {
        val array=JSONArray()
        items.take(Limits.MAX_HISTORY).forEach{array.put(JSONObject().put("before",readingJson(it.before))
            .put("after",readingJson(it.after)).put("plan",it.planTitle).put("savedAt",it.savedAt))}
        val encoded=array.toString();require(encoded.length<=Limits.MAX_JSON)
        prefs.edit().putString("history",encoded).apply()
    }
    // commit makes deletion status explicit; it also removes legacy keys on a full reset.
    fun clearHistory(): Boolean=prefs.edit().remove("history").commit()
    fun clearAll(): Boolean=prefs.edit().clear().commit()
    companion object {
        fun emptyProfile(kind: Kind,name: String="我的相機",id: String=UUID.randomUUID().toString())=
            Profile.partial(id,kind,name,null,null,null,null,null,null,null,null,null,null,doubleArrayOf(),doubleArrayOf())
        private fun text(j: JSONObject,key: String,max: Int,fallback: String?=null): String {
            val value=if(fallback==null)j.getString(key)else j.optString(key,fallback)
            Limits.text(value,max,key);return value
        }
        private fun number(j: JSONObject,key: String): Double? =
            if(j.isNull(key))null else j.getDouble(key).also{require(it.isFinite()&&it>0)}
        private fun integer(j: JSONObject,key: String): Int? {
            if(j.isNull(key))return null
            val value=j.getDouble(key)
            require(value.isFinite()&&value in 1.0..1000000.0&&value==kotlin.math.floor(value))
            return value.toInt()
        }
        private fun optionalBoolean(j: JSONObject,key: String): Boolean? =
            if(j.isNull(key))null else j.getBoolean(key)
        private fun steps(j: JSONObject,key: String): DoubleArray {
            val array=j.optJSONArray(key)?:return doubleArrayOf()
            require(array.length()<=Limits.MAX_STEPS)
            return DoubleArray(array.length()){array.getDouble(it)}
        }
        private fun profileJson(p: Profile)=JSONObject().put("id",p.id).put("kind",p.kind.name).put("name",p.name)
            .put("aperture",p.aperture?:JSONObject.NULL).put("shutter",p.shutter?:JSONObject.NULL)
            .put("minAperture",p.minAperture?:JSONObject.NULL).put("maxAperture",p.maxAperture?:JSONObject.NULL)
            .put("fastest",p.fastest?:JSONObject.NULL).put("slowest",p.slowest?:JSONObject.NULL)
            .put("focalLength",p.focalLength?:JSONObject.NULL).put("minFocus",p.minFocus?:JSONObject.NULL)
            .put("guideNumber",p.guideNumber?:JSONObject.NULL).put("hasFlash",p.hasFlash?:JSONObject.NULL)
            .put("apertures",JSONArray(p.apertures.toList())).put("shutters",JSONArray(p.shutters.toList()))
        private fun profileFromJson(j: JSONObject,id: String?=null): Profile {
            val kind=Kind.valueOf(j.getString("kind"));val name=text(j,"name",100)
            return Profile.partial(id?:text(j,"id",200,"legacy:"+kind.name+":"+name),kind,name,
                number(j,"aperture"),number(j,"shutter"),number(j,"minAperture"),number(j,"maxAperture"),
                number(j,"fastest"),number(j,"slowest"),number(j,"focalLength"),number(j,"minFocus"),
                number(j,"guideNumber"),optionalBoolean(j,"hasFlash"),steps(j,"apertures"),steps(j,"shutters"))
        }
        private fun readingJson(r: Reading)=JSONObject().put("profile",profileJson(r.profile))
            .put("iso",r.iso?:JSONObject.NULL).put("ev100",r.ev100).put("distance",r.distance?:JSONObject.NULL)
            .put("intent",r.intent.name).put("flash",r.flash).put("source",r.source).put("signature",r.signature)
            .put("timeMillis",r.timeMillis).put("distanceSource",r.distanceSource)
        private fun readingFromJson(j: JSONObject)=Reading(profileFromJson(j.getJSONObject("profile")),
            integer(j,"iso"),j.getDouble("ev100"),number(j,"distance"),Intent.valueOf(j.getString("intent")),
            j.getBoolean("flash"),text(j,"source",160),text(j,"signature",256),j.getLong("timeMillis"),
            text(j,"distanceSource",160,"既有距離紀錄"))
    }
}
