package com.filmwise.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.filmwise.core.ExposureEngine as E
import com.filmwise.core.ExposureEngine.*
import java.util.UUID

data class CameraDraft(
    val id: String=UUID.randomUUID().toString(),val name: String="",val kind: Kind=Kind.FIXED,
    val iso: Int?=null,val filmName: String="",val aperture: Double?=null,val shutter: Double?=null,
    val focal: Double?=null,val minFocus: Double?=null,val gn: Double?=null,val flash: Boolean?=null,
    val apertures: List<Double> = emptyList(),val shutters: List<Double> = emptyList()
) {
    fun entry(): CameraEntry {
        val a=apertures.sorted().distinct()
        val t=shutters.sorted().distinct()
        val p=Profile.partial(id,kind,name,aperture,shutter,a.firstOrNull(),a.lastOrNull(),
            t.firstOrNull(),t.lastOrNull(),focal,minFocus,gn,flash,a.toDoubleArray(),t.toDoubleArray())
        return CameraEntry(p,iso,filmName.trim())
    }
    companion object {
        fun from(e: CameraEntry)=CameraDraft(e.id,e.profile.name,e.profile.kind,e.filmISO,e.filmName,
            e.profile.aperture,e.profile.shutter,e.profile.focalLength,e.profile.minFocus,
            e.profile.guideNumber,e.profile.hasFlash,e.profile.apertures.toList(),e.profile.shutters.toList())
    }
}
val commonApertures=listOf(2.8,4.0,5.6,8.0,11.0,16.0,22.0,1.4,1.8,2.0,3.5,9.0,10.0,1.0,1.2,1.7,4.5,6.3,9.5,32.0)
val commonShutters=listOf(1.0/60,1.0/125,1.0/250,1.0/500,1.0/1000,1.0/30,1.0/15,1.0/2000,1.0/4000,1.0/8000,1.0/25,1.0/40,1.0/50,1.0/80,1.0/100,1.0/200,.125,.25,.5,1.0,2.0,4.0,8.0)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> QuickSelect(label: String,value: T?,options: List<T>,format: (T)->String,
                    onSelect:(T?)->Unit,modifier: Modifier=Modifier,allowUnknown: Boolean=true,
                    unknownText: String="不知道・留空",customAction:(()->Unit)?=null) {
    var expanded by remember{mutableStateOf(false)}
    ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it},modifier=modifier.fillMaxWidth()){
        OutlinedTextField(value=value?.let(format)?:unknownText,onValueChange={},readOnly=true,
            label={Text(label)},leadingIcon={FieldIcon(label)},
            trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)},colors=warmFieldColors(),
            modifier=Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
            shape=RoundedCornerShape(17.dp),singleLine=true)
        ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false},
            modifier=Modifier.heightIn(max=340.dp),shape=RoundedCornerShape(20.dp),
            containerColor=MenuCream,tonalElevation=0.dp,shadowElevation=8.dp,border=BorderStroke(1.dp,Border)){
            @Composable fun Choice(text: String,selected: Boolean,action:()->Unit){
                DropdownMenuItem(text={Text(text,color=Ink)},leadingIcon={FieldIcon(label)},
                    trailingIcon={if(selected)Icon(Icons.Default.Check,"已選擇",tint=Coffee)},
                    modifier=Modifier.padding(horizontal=7.dp).clip(RoundedCornerShape(12.dp))
                        .background(if(selected)Sand else MenuCream),
                    onClick={action();expanded=false})
            }
            if(allowUnknown)Choice(unknownText,value==null){onSelect(null)}
            options.forEach{option->Choice(format(option),value==option){onSelect(option)}}
            if(customAction!=null){
                HorizontalDivider(Modifier.padding(horizontal=14.dp,vertical=6.dp),color=Border)
                DropdownMenuItem(text={Text("自訂數值…",color=Coffee)},leadingIcon={FieldIcon("設定")},
                    onClick={expanded=false;customAction()})
            }
        }
    }
}
@Composable
fun QuickNumber(label: String,value: Double?,options: List<Double>,format:(Double)->String,
                onSelect:(Double?)->Unit,customHint: String="輸入數值") {
    var custom by remember{mutableStateOf(false)}
    var text by remember{mutableStateOf("")}
    QuickSelect(label,value,options,format,onSelect,customAction={text=value?.toString()?:"";custom=true})
    if(custom)AlertDialog(onDismissRequest={custom=false},title={Text(label)},text={
        OutlinedTextField(value=text,onValueChange={text=it.take(32)},label={Text(customHint)},singleLine=true,
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
    },confirmButton={TextButton(onClick={onSelect(text.toDouble());custom=false},
        enabled=text.toDoubleOrNull()?.let{it.isFinite()&&it>0}==true){Text("套用")}},
        dismissButton={TextButton(onClick={custom=false}){Text("取消")}})
}
@Composable
private fun StopSelector(label: String,values: List<Double>,selected: List<Double>,format:(Double)->String,
                         onSelect:(List<Double>)->Unit) {
    var open by remember{mutableStateOf(false)}
    var checked by remember{mutableStateOf(selected.toSet())}
    OutlinedButton(onClick={checked=selected.toSet();open=true},modifier=Modifier.fillMaxWidth(),
        shape=RoundedCornerShape(15.dp),contentPadding=PaddingValues(15.dp)){
        Column(Modifier.fillMaxWidth()){
            Text(label,style=MaterialTheme.typography.labelMedium)
            Text(if(selected.isEmpty())"不知道・可以之後補上" else selected.joinToString("、",transform=format),
                style=MaterialTheme.typography.bodySmall)
        }
    }
    if(open)AlertDialog(onDismissRequest={open=false},title={Text(label)},text={
        Column(Modifier.heightIn(max=340.dp).verticalScroll(rememberScrollState())){
            TextButton(onClick={checked=emptySet()}){Text("不知道／清空選擇")}
            values.forEach {n->
                Row {
                    Checkbox(checked=n in checked,onCheckedChange={checked=if(it)checked+n else checked-n})
                    TextButton(onClick={checked=if(n in checked)checked-n else checked+n}){Text(format(n))}
                }
            }
        }
    },confirmButton={TextButton(onClick={onSelect(checked.toList().sorted());open=false}){Text("完成")}},
        dismissButton={TextButton(onClick={open=false}){Text("取消")}})
}
@Composable
fun CameraEditor(model: FilmwiseModel) {
    val d=model.editorDraft?:return
    var advanced by remember{mutableStateOf(false)}
    var problem by remember{mutableStateOf<String?>(null)}
    fun update(next: CameraDraft){model.editorDraft=next;problem=null}
    PageTitle(if(model.editingId==null)"新增相機" else "編輯相機","知道的先選，不知道的就留空。")
    OutlinedTextField(value=d.name,onValueChange={update(d.copy(name=it.take(100)))},
        label={Text("替相機取個名字")},leadingIcon={FieldIcon("相機")},colors=warmFieldColors(),placeholder={Text("例如：旅行用傻瓜機")},
        modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),singleLine=true)
    QuickSelect("相機類型",d.kind,Kind.values().toList(),::kindLabel,
        {if(it!=null)update(d.copy(kind=it,aperture=null,shutter=null,apertures=emptyList(),shutters=emptyList()))},
        allowUnknown=false)
    SectionLabel("這台相機裡的底片")
    QuickSelect("底片 ISO",d.iso,listOf(100,200,400,800,1600,50,125,160,250,320,500,640,3200),
        {it.toString()},{update(d.copy(iso=it))})
    Hint("底片盒上常見 100、200、400、800 等數字。一卷底片通常沿用同一個 ISO。")
    OutlinedTextField(value=d.filmName,onValueChange={update(d.copy(filmName=it.take(120)))},
        label={Text("底片名稱（選填）")},leadingIcon={FieldIcon("底片")},colors=warmFieldColors(),placeholder={Text("例如：Kodak Gold 200")},
        modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),singleLine=true)
    SectionLabel(if(d.kind==Kind.FIXED)"固定的拍攝設定" else "目前的拍攝設定")
    if(d.kind!=Kind.AUTO){
        QuickNumber("光圈",d.aperture,commonApertures,{"f/"+numberLabel(it)},
            {update(d.copy(aperture=it))})
        QuickNumber("快門",d.shutter,commonShutters,E::shutter,
            {update(d.copy(shutter=it))},"秒數，例如 0.01 = 1/100 秒")
    }else WarmNote("交給相機決定","自動曝光相機會自行選擇光圈與快門，這裡保留為「不知道」。")
    QuickSelect("相機是否有可用閃光",d.flash,listOf(true,false),{if(it)"有" else "沒有"},
        {update(d.copy(flash=it))})
    TextButton(onClick={advanced=!advanced}){Text(if(advanced)"收起更多規格" else "更多規格・選填")}
    if(advanced){
        QuickNumber("鏡頭焦距",d.focal,listOf(21.0,24.0,28.0,31.0,35.0,38.0,40.0,45.0,50.0,55.0,80.0,85.0,105.0,135.0,200.0),
            {numberLabel(it)+" mm"},{update(d.copy(focal=it))})
        QuickNumber("最近對焦距離",d.minFocus,listOf(.25,.3,.35,.4,.5,.6,.7,.8,1.0,1.2,1.5,2.0,3.0),
            {numberLabel(it)+" 公尺"},{update(d.copy(minFocus=it))})
        if(d.flash!=false){
            QuickNumber("閃光 GN（ISO 100，公尺）",d.gn,listOf(6.0,8.0,10.0,12.0,14.0,16.0,20.0,24.0,28.0,32.0,36.0,40.0,60.0),
                {numberLabel(it)},{update(d.copy(gn=it))})
            Hint("GN 通常可在說明書找到。留空時，不會猜測閃光有效距離。")
        }
        if(d.kind==Kind.MANUAL){
            StopSelector("鏡頭可調整的光圈",commonApertures,d.apertures,{"f/"+numberLabel(it)},
                {update(d.copy(apertures=it))})
            StopSelector("相機可調整的快門",commonShutters,d.shutters,E::shutter,
                {update(d.copy(shutters=it))})
            Hint("勾選相機真的有的刻度，才能推薦具體的光圈與快門組合。")
        }
    }
    problem?.let{Text(it,color=MaterialTheme.colorScheme.error)}
    ModelError(model)
    PrimaryAction("儲存這台相機",enabled=d.name.isNotBlank()){
        runCatching{d.entry()}.onSuccess{model.saveCamera(it)}.onFailure{problem=it.message}
    }
    Hint("沒有填的數值會保留為「不知道」，日後都能再編輯。")
}


fun kindLabel(kind: Kind)=when(kind){Kind.FIXED->"傻瓜相機・固定設定";Kind.AUTO->"傻瓜相機・自動曝光";Kind.MANUAL->"手動底片相機"}



private fun numberLabel(value: Double)=java.math.BigDecimal.valueOf(value).stripTrailingZeros().toPlainString()



