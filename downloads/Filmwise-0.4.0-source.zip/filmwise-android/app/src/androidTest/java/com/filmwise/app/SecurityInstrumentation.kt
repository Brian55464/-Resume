package com.filmwise.app

import android.app.Activity
import android.app.Instrumentation
import android.os.Bundle
import com.filmwise.core.ExposureEngine.*
import org.json.JSONArray
import org.json.JSONObject

/** Destructive storage tests are confined to a separate, explicit QA package. */
class SecurityInstrumentation: Instrumentation() {
    private var checks=0
    private fun check(value: Boolean,message: String){if(!value)error(message);checks++}
    override fun onCreate(arguments: Bundle?){super.onCreate(arguments);start()}
    override fun onStart(){
        val result=Bundle()
        try{
            val context=targetContext
            require(context.packageName=="com.filmwise.app.securityqa"){"Storage tests require the isolated security QA package."}
            val prefs=context.getSharedPreferences("filmwise-v1",0)
            prefs.edit().clear().commit()
            val profile=SessionStore.emptyProfile(Kind.FIXED,"我的相機","camera-one")
            val camera=CameraEntry(profile,400,"底片")
            var store=SessionStore(context)
            store.saveCameras(listOf(camera),camera.id)
            check(SessionStore(context).cameras().single().profile.name=="我的相機","Existing cameras survive reopen")
            check(store.selectedCamera()==camera.id,"Selected camera persists")
            val before=Reading(profile,400,7.0,null,Intent.STILL,false,"test","same",1000,"unknown")
            val after=Reading(profile,400,11.0,null,Intent.STILL,false,"test","same",2000,"unknown")
            store.saveHistory(listOf(SavedComparison(before,after,"靠近光源",2000)))
            check(store.history().size==1,"History persists")
            store.acceptArPrivacy();store.saveArPreferred(true)
            check(SessionStore(context).arPrivacyAccepted(),"AR agreement persists")
            store.revokeArPrivacy()
            check(!store.arPrivacyAccepted()&&!store.arPreferred(),"Revoking disables persisted AR")
            store.saveCalibration("focus:0",1.0)
            check(store.clearHistory()&&SessionStore(context).history().isEmpty(),"History deletion persists")
            check(store.cameras().size==1&&store.calibration("focus:0")==1.0,"History deletion preserves camera and calibration")
            val valid=JSONArray(prefs.getString("camerasV2","[]")).getJSONObject(0)
            val bad=JSONObject(valid.toString())
            bad.getJSONObject("profile").put("name","x".repeat(101))
            prefs.edit().putString("camerasV2",JSONArray().put(bad).put(valid).toString()).commit()
            check(store.cameras().size==1,"Malformed entry skipped without losing good entry")
            val manyStops=JSONObject(valid.toString())
            manyStops.getJSONObject("profile").put("apertures",JSONArray(List(65){2.8}))
            prefs.edit().putString("camerasV2",JSONArray().put(manyStops).toString()).commit()
            check(store.cameras().isEmpty(),"Unbounded persisted dial arrays rejected")
            prefs.edit().putString("camerasV2","x".repeat(524289)).commit()
            check(store.cameras().isEmpty(),"Oversized JSON rejected before parsing")
            prefs.edit().putString("camerasV2","not json").putString("history","[").commit()
            check(store.cameras().isEmpty()&&store.history().isEmpty(),"Corrupt JSON does not crash")
            prefs.edit().putString("calibration.focus:0","spoof").putString("arPrivacyAcceptedV1","true").commit()
            check(store.calibration("focus:0")==0.0&&!store.arPrivacyAccepted(),"Wrong preference types fail closed")
            prefs.edit().putFloat("calibration.focus:0",Float.NaN).commit()
            check(store.calibration("focus:0")==0.0,"Nonfinite calibration rejected")
            var rejected=false
            try{store.saveCameras(List(51){camera},null)}catch(e: IllegalArgumentException){rejected=true}
            check(rejected,"Too many cameras rejected")
            // Retain old migration keys to prove a full reset cannot resurrect deleted cameras.
            prefs.edit().putBoolean("profileConfirmed",true).putString("profile",valid.getJSONObject("profile").toString()).putInt("filmISO",400).commit()
            check(store.clearAll()&&prefs.all.isEmpty(),"Full reset removes legacy keys, AR and calibration")
            store=SessionStore(context)
            check(store.cameras().isEmpty()&&store.history().isEmpty()&&!store.arPrivacyAccepted(),"Restart cannot restore data after reset")
            prefs.edit().clear().putBoolean("profileConfirmed",true).putString("profile",valid.getJSONObject("profile").toString()).putInt("filmISO",400).commit()
            check(SessionStore(context).cameras().single().filmISO==400,"Valid legacy camera still migrates")
            prefs.edit().clear().commit()
            val model=FilmwiseModel(context.applicationContext as android.app.Application)
            check(model.usesQuickMeter&&model.cameras.isEmpty(),"Fresh install can meter without camera setup")
            model.mode=MeterMode.DEMO;model.showTutorial=false
            model.capture(1000,false)
            check(com.filmwise.core.QuickExposure.isQuick(model.before)&&model.before?.iso==null,
                "Unknown ISO remains unknown in a captured direct reading")
            check(model.cameras.isEmpty(),"Direct capture does not add a fake saved camera")
            val isoPlan=com.filmwise.core.ExposureEngine.plans(model.before).first{it.id=="film-info"}
            model.choose(isoPlan)
            check(model.showReferenceISO&&model.screen==Screen.SHOOT,"ISO advice opens a direct ISO choice without camera setup")
            model.setReferenceISO(null);model.capture(1000,false)
            val plan=com.filmwise.core.ExposureEngine.plans(model.before).first{it.id=="light"}
            model.choose(plan);model.demoEV=11.0;model.capture(2000,true)
            check(model.after!=null&&com.filmwise.core.ExposureEngine.comparable(model.before,model.after),"Direct readings can be compared")
            model.saveComparison()
            check(SessionStore(context).history().size==1&&SessionStore(context).cameras().isEmpty(),"Direct history survives without saved cameras")
            model.setReferenceISO(100)
            check(model.before==null&&model.quickISO==100,"Changing reference ISO resets an in-progress comparison")
            model.capture(3000,false)
            check(model.before?.iso==100,"Chosen ISO is frozen in the direct result")
            model.saveCamera(camera)
            check(!model.usesQuickMeter&&model.activeCamera?.filmISO==400,"Saved-camera ISO is independent from reference ISO")
            model.useQuickMeter()
            check(model.usesQuickMeter&&model.cameras.size==1,"Returning to direct meter preserves saved cameras")
            val reopened=FilmwiseModel(context.applicationContext as android.app.Application)
            check(reopened.usesQuickMeter&&reopened.quickISO==100,"Direct mode and reference ISO survive restart")
            reopened.selectCamera(camera.id)
            check(!reopened.usesQuickMeter&&reopened.activeCamera?.filmISO==400,"Switching back restores the camera's own film settings")
            reopened.clearAllData()
            check(reopened.usesQuickMeter&&reopened.quickISO==null&&reopened.cameras.isEmpty(),"Full reset clears new direct-meter preferences")
            result.putString("result","PASS: $checks on-device storage/privacy/direct-meter checks")
            finish(Activity.RESULT_OK,result)
        }catch(e: Throwable){
            result.putString("error",e.javaClass.simpleName+": "+e.message)
            finish(Activity.RESULT_CANCELED,result)
        }
    }
}
