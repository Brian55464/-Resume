# 片刻 Filmwise 0.4.0

Android 底片攝影測光輔助工具。Kotlin、Jetpack Compose、CameraX / Camera2、選用 ARCore。

功能包括直接測光、ISO 參考換算、多相機設定、通用曝光建議、前後比較與本機歷史。最低 Android 8.0（API 26），compile/target API 35。

## 開啟
Android Studio 開啟此資料夾，使用 JDK 17 或 21，設定自己的 Android SDK 位置，完成 Gradle Sync 後執行 app。

核心檢查與 debug 建置：`./gradlew :core:engineChecks :app:assembleDebug`

## 資料與限制
相機設定與歷史儲存於本機。畫面讀值為手機自動曝光參考，並非已校準的專業點測光；AR 估距需裝置支援。教學圖片與示範模式數值不代表現場測量。

此公開來源包不包含電腦本機路徑、快取、私密簽署金鑰或個人資料。若自行發佈 release，請使用自己的簽署設定。

全字庫正楷體字型授權見 docs/FONT-LICENSE.txt。
