// Security fixes for dependencies used by the Android build tools, not app features.
buildscript {
    configurations.classpath {
        resolutionStrategy.eachDependency {
            val patched = when {
                requested.group == "io.netty" && !requested.name.startsWith("netty-tcnative") -> "4.1.137.Final"
                requested.group == "com.google.guava" && requested.name == "guava" -> "33.7.2-jre"
                requested.group == "org.bouncycastle" -> "1.85"
                requested.group == "org.apache.commons" && requested.name == "commons-compress" -> "1.28.0"
                requested.group == "org.bitbucket.b_c" && requested.name == "jose4j" -> "0.9.6"
                requested.group == "org.jdom" && requested.name == "jdom2" -> "2.0.6.1"
                else -> null
            }
            if (patched != null) { useVersion(patched); because("Remediate known OSV advisories; see docs/SECURITY-REVIEW-0.3.1.md") }
        }
    }
}
plugins {
    id("com.android.application") version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.4.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.21" apply false
}
