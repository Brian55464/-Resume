package com.filmwise.core;

/** Shared limits protect calculations and UI from corrupt/pasted oversized data. */
public final class InputLimits {
    public static final int MAX_CAMERAS=50, MAX_HISTORY=30, MAX_STEPS=64, MAX_JSON=524288;
    private InputLimits() {}
    public static void text(String value,int max,String label) {
        if(value==null||value.length()>max)throw new IllegalArgumentException(label+"過長，請縮短後再儲存。");
        for(int i=0;i<value.length();i++){
            char c=value.charAt(i);
            if(Character.isISOControl(c)||c>=0x202a&&c<=0x202e||c>=0x2066&&c<=0x2069)
                throw new IllegalArgumentException(label+"含有不支援的隱藏控制字元，請重新輸入。");
        }
    }
    public static void range(Double value,double min,double max,String label) {
        if(value!=null&&(!Double.isFinite(value)||value<min||value>max))
            throw new IllegalArgumentException(label+"超出可用範圍，請核對或選擇「不知道」。");
    }
    public static void steps(double[] values,double min,double max) {
        if(values==null)return;
        if(values.length>MAX_STEPS)throw new IllegalArgumentException("每種刻度最多保留 64 個數值。");
        for(double v:values)range(v,min,max,"刻度");
    }
    public static void iso(Integer iso) {
        if(iso!=null&&(iso<1||iso>1000000))throw new IllegalArgumentException("請核對底片 ISO。");
    }
}
