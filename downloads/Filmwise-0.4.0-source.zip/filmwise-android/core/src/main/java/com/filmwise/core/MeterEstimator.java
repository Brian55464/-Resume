package com.filmwise.core;

import java.util.ArrayDeque;
import java.util.Arrays;

/** Gates incomplete, unsettled and stale Camera2 metadata instead of inventing a reading. */
public final class MeterEstimator {
    public static final class Sample {
        public final Double ev100;
        public final String status;
        public final long monotonicMillis;
        public Sample(Double ev100,String status,long monotonicMillis) {
            this.ev100=ev100; this.status=status; this.monotonicMillis=monotonicMillis;
        }
        public boolean fresh(long now) {
            return ev100!=null&&Double.isFinite(ev100)&&ev100>=-28&&ev100<=36&&now>=monotonicMillis&&now-monotonicMillis<=1500;
        }
    }
    private final ArrayDeque<Double> window=new ArrayDeque<>();
    private long lastAccepted=0;
    public Sample accept(Long exposureNanos,Integer sensorISO,Float aperture,Integer boost,
                         Integer aeState,long now) {
        if(exposureNanos==null||sensorISO==null||aperture==null||exposureNanos<=0
                ||sensorISO<=0||!ExposureEngine.positive(aperture)) {
            window.clear();
            return new Sample(null,"手機未提供完整曝光資料，可改用外部測光表輸入。",now);
        }
        // Camera2 AE_STATE_CONVERGED = 2; a searching/flash-required state is not a valid light reading.
        if(aeState==null||aeState!=2) {
            window.clear();
            return new Sample(null,aeState!=null&&aeState==4?
                    "現場過暗或相機需要閃光，目前無法可靠估算。":"等待相機曝光穩定…",now);
        }
        if(boost!=null&&boost<=0) {
            window.clear(); return new Sample(null,"感光增益資料無效。",now);
        }
        if(now-lastAccepted>1500) window.clear();
        double totalISO=sensorISO*(boost==null?1.0:boost/100.0);
        double value=ExposureEngine.exposureEV(aperture,exposureNanos/1_000_000_000.0,totalISO);
        if(!Double.isFinite(value)||value< -28||value>36) { window.clear(); return new Sample(null,"無效的測光資料。",now); }
        lastAccepted=now;
        window.addLast(value);
        while(window.size()>6) window.removeFirst();
        if(window.size()<6) return new Sample(null,"正在收集穩定讀值…",now);
        double[] values=new double[window.size()];
        int i=0; for(double v:window) values[i++]=v;
        Arrays.sort(values);
        if(values[values.length-1]-values[0]>.35) return new Sample(null,"光線仍在變動，請對準主體保持片刻。",now);
        return new Sample((values[2]+values[3])/2,"手機估算 · 建議先與可靠測光表校對",now);
    }
}
