package com.filmwise.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Nullable facts stay unknown; suggestions never invent a camera setting or distance. */
public final class ExposureEngine {
    private ExposureEngine() {}
    public enum Kind { FIXED, AUTO, MANUAL }
    public enum Intent { STILL, MOVING, LANDSCAPE }

    public static final class Profile {
        public final String id, name;
        public final Kind kind;
        public final Double aperture, shutter, minAperture, maxAperture, fastest, slowest;
        public final Double focalLength, minFocus, guideNumber;
        public final Boolean hasFlash;
        private final double[] apertures, shutters;

        public Profile(Kind kind,String name,double a,double t,double minA,double maxA,double fastest,
                       double slowest,double focal,double focus,double gn,boolean flash) {
            this(kind,name,a,t,minA,maxA,fastest,slowest,focal,focus,gn,flash,
                    defaultApertures(minA,maxA),defaultShutters(fastest,slowest));
        }
        public Profile(Kind kind,String name,double a,double t,double minA,double maxA,double fastest,
                       double slowest,double focal,double focus,double gn,boolean flash,
                       double[] apertures,double[] shutters) {
            this("legacy:"+kind+":"+name,kind,name,a,t,minA,maxA,fastest,slowest,focal,focus,
                    gn==0?null:gn,flash,apertures,shutters);
        }
        private Profile(String id,Kind kind,String name,Double a,Double t,Double minA,Double maxA,
                        Double fastest,Double slowest,Double focal,Double focus,Double gn,
                        Boolean flash,double[] apertures,double[] shutters) {
            if(id==null||id.trim().isEmpty()||kind==null||name==null||name.trim().isEmpty())
                throw new IllegalArgumentException("請為相機取個名字。");
            InputLimits.text(id,200,"相機識別碼");InputLimits.text(name,100,"相機名稱");
            InputLimits.range(a,.1,256,"光圈");InputLimits.range(minA,.1,256,"光圈");InputLimits.range(maxA,.1,256,"光圈");
            InputLimits.range(t,1.0/1000000,86400,"快門");InputLimits.range(fastest,1.0/1000000,86400,"快門");InputLimits.range(slowest,1.0/1000000,86400,"快門");
            InputLimits.range(focal,.1,10000,"焦距");InputLimits.range(focus,.01,10000,"對焦距離");InputLimits.range(gn,.1,1000,"閃光 GN");
            InputLimits.steps(apertures,.1,256);InputLimits.steps(shutters,1.0/1000000,86400);
            for(Double v:new Double[]{a,t,minA,maxA,fastest,slowest,focal,focus,gn})
                if(v!=null&&!positive(v)) throw new IllegalArgumentException("數值需大於零，或選擇「不知道」。");
            if(minA!=null&&maxA!=null&&minA>maxA || fastest!=null&&slowest!=null&&fastest>slowest)
                throw new IllegalArgumentException("請確認器材的可用範圍。");
            this.id=id; this.kind=kind; this.name=name.trim();
            this.aperture=kind==Kind.AUTO?null:a; this.shutter=kind==Kind.AUTO?null:t;
            this.minAperture=minA; this.maxAperture=maxA; this.fastest=fastest; this.slowest=slowest;
            this.focalLength=focal; this.minFocus=focus; this.guideNumber=gn; this.hasFlash=flash;
            this.apertures=checkedSteps(apertures,minA,maxA);
            this.shutters=checkedSteps(shutters,fastest,slowest);
            if(kind==Kind.MANUAL && (a!=null&&this.apertures.length>0&&!contains(this.apertures,a)
                    ||t!=null&&this.shutters.length>0&&!contains(this.shutters,t)))
                throw new IllegalArgumentException("目前設定與可用刻度不一致，請核對或保留「不知道」。");
        }
        public static Profile partial(String id,Kind kind,String name,Double a,Double t,
                                      Double minA,Double maxA,Double fastest,Double slowest,
                                      Double focal,Double focus,Double gn,Boolean flash,
                                      double[] apertures,double[] shutters) {
            return new Profile(id,kind,name,a,t,minA,maxA,fastest,slowest,focal,focus,gn,flash,apertures,shutters);
        }
        public double[] getApertures() {return apertures.clone();}
        public double[] getShutters() {return shutters.clone();}
        public Profile withSettings(double a,double t) {
            if(kind!=Kind.MANUAL) throw new IllegalStateException("這台相機不支援手動曝光設定。");
            return partial(id,kind,name,a,t,minAperture,maxAperture,fastest,slowest,
                    focalLength,minFocus,guideNumber,hasFlash,apertures,shutters);
        }
    }

    public static final class Reading {
        public final Profile profile;
        public final Integer iso;
        public final double ev100;
        public final Double distance;
        public final Intent intent;
        public final boolean flash;
        public final String source, signature, distanceSource;
        public final long timeMillis;
        public Reading(Profile p,int iso,double ev,double distance,Intent intent,boolean flash,
                       String source,String signature,long time) {
            this(p,iso,ev,distance,intent,flash,source,signature,time,"既有距離紀錄");
        }
        public Reading(Profile p,Integer iso,double ev,Double distance,Intent intent,boolean flash,
                       String source,String signature,long time,String distanceSource) {
            if(p==null||iso!=null&&iso<=0||!Double.isFinite(ev)
                    ||distance!=null&&!positive(distance)||intent==null||source==null||signature==null)
                throw new IllegalArgumentException("測量資料無效。");
            InputLimits.iso(iso);InputLimits.range(ev,-32,40,"光線讀值");
            InputLimits.text(source,160,"來源");InputLimits.text(signature,256,"讀值識別碼");
            if(distanceSource!=null)InputLimits.text(distanceSource,160,"距離來源");
            this.profile=p; this.iso=iso; this.ev100=ev; this.distance=distance; this.intent=intent;
            this.flash=flash; this.source=source; this.signature=signature; this.timeMillis=time;
            this.distanceSource=distance==null?"尚未取得距離":distanceSource;
        }
    }
    public static final class Pair {
        public final double aperture, shutter, difference;
        Pair(double a,double t,double d){aperture=a;shutter=t;difference=d;}
    }
    public static final class Assessment {
        public final String title, detail;
        public final boolean caution;
        public final Boolean focusOK, motionRisk;
        public final Double exposureDifference, actualAperture, actualShutter, flashMax;
        public final boolean flashUpperBoundOnly;
        Assessment(String title,String detail,boolean caution,Boolean focus,Boolean motion,
                   Double difference,Double a,Double t,Double flashMax,boolean upper) {
            this.title=title;this.detail=detail;this.caution=caution;this.focusOK=focus;this.motionRisk=motion;
            this.exposureDifference=difference;this.actualAperture=a;this.actualShutter=t;
            this.flashMax=flashMax;this.flashUpperBoundOnly=upper;
        }
    }
    public static final class Plan {
        public final String id,title,description;
        public final Pair pair;
        Plan(String id,String title,String description,Pair pair) {
            this.id=id;this.title=title;this.description=description;this.pair=pair;
        }
    }
    public static boolean positive(double v){return Double.isFinite(v)&&v>0;}
    public static double log2(double v){return Math.log(v)/Math.log(2);}
    public static double exposureEV(double a,double t,double iso){
        if(!positive(a)||!positive(t)||!positive(iso))throw new IllegalArgumentException("曝光參數無效。");
        return log2(a*a/t)-log2(iso/100.0);
    }
    public static double referenceShutter(Reading r){
        return r.intent==Intent.MOVING?1.0/250:1.0/Math.max(60,r.profile.focalLength==null?60:r.profile.focalLength);
    }
    public static Pair bestPair(Reading r){
        Profile p=r.profile;
        if(p.kind!=Kind.MANUAL||r.iso==null||p.apertures.length==0||p.shutters.length==0)return null;
        Pair best=null;double bestScore=Double.POSITIVE_INFINITY;
        for(double a:p.apertures)for(double t:p.shutters){
            double d=r.ev100-exposureEV(a,t,r.iso);
            double score=Math.abs(d)*10+Math.max(0,log2(t/referenceShutter(r)))*2
                    +Math.abs(log2(a/(r.intent==Intent.LANDSCAPE?8:2.8)))*.4;
            if(score<bestScore){bestScore=score;best=new Pair(a,t,d);}
        }
        return best;
    }
    public static Assessment assess(Reading r){
        Profile p=r.profile;
        boolean auto=p.kind==Kind.AUTO;
        Double a=auto?null:p.aperture,t=auto?null:p.shutter;
        Double diff=a!=null&&t!=null&&r.iso!=null?r.ev100-exposureEV(a,t,r.iso):null;
        Double fastestEstimate=t;
        if(auto&&p.minAperture!=null&&r.iso!=null) fastestEstimate=p.minAperture*p.minAperture/(Math.pow(2,r.ev100)*r.iso/100.0);
        Boolean motion=fastestEstimate==null?null:fastestEstimate>referenceShutter(r);
        Boolean focus=r.distance==null||p.minFocus==null?null:r.distance>=p.minFocus;
        Double flashA=auto?p.minAperture:a;
        Double flashMax=Boolean.TRUE.equals(p.hasFlash)&&p.guideNumber!=null&&r.iso!=null&&flashA!=null?
                p.guideNumber*Math.sqrt(r.iso/100.0)/flashA:null;
        String title,detail;boolean caution;
        if(Boolean.FALSE.equals(focus)){
            title="先後退一點，再拍這張";
            detail="估算主體距離小於這台相機的最近對焦距離，建議後退後重新點選。";
            caution=true;
        }else if(r.flash){
            if(flashMax==null||r.distance==null){
                title="已加入閃光建議，距離仍待確認";
                detail="相機或距離資料不足，先依相機說明書確認閃光有效範圍；遠方背景仍可能較暗。";
                caution=true;
            }else if(r.distance>flashMax){
                title="人物可能太遠，閃光照不到";
                detail="估算有效上限約 "+one(flashMax)+" 公尺。可走近主體，或移到較亮的位置。";
                caution=true;
            }else{
                title=auto?"人物在最佳條件估算上限內":"人物在估算閃光上限內";
                detail=(auto?"自動相機的實際範圍還取決於它選擇的光圈。":"此估算適用於直打閃光。")
                        +"太近可能過亮，背景也不一定會一起變亮。";
                caution=auto;
            }
        }else if(diff!=null){
            title=diff < -1?"這裡偏暗，可以考慮補光":diff>1?"這裡偏亮，留意明亮區域":
                    Boolean.TRUE.equals(motion)?"亮度接近，拍攝時請穩住":"光線與目前設定接近參考";
            detail="目前設定相較測光參考"+(diff<0?"少約 ":"多約 ")+one(Math.abs(diff))+" 格光。"
                    +(Boolean.TRUE.equals(motion)?"主體移動或手持晃動仍可能造成模糊。":"可依想保留的氣氛與主體再調整。");
            caution=Math.abs(diff)>1||Boolean.TRUE.equals(motion);
        }else if(auto&&fastestEstimate!=null){
            title=Boolean.TRUE.equals(motion)?"光線偏弱，自動相機也可能拍糊":"可以先嘗試目前的拍法";
            detail="以最大光圈估算約需 "+shutter(fastestEstimate)+"；實際設定仍由相機決定。"
                    +(Boolean.TRUE.equals(motion)?"可考慮增加光線或使用閃光。":"建議拍攝時保持穩定。");
            caution=Boolean.TRUE.equals(motion);
        }else{
            title=r.ev100<8?"現場光線較弱，先評估補光":"先保留氣氛，再確認主體";
            detail="部分相機資料選了「不知道」，因此先提供通用建議。"
                    +(r.iso==null?"補上底片 ISO 後，可以提供更多曝光判斷。":"不會猜測你的實際光圈或快門。");
            caution=true;
        }
        if(r.distance==null)detail+=" 尚未取得距離，暫不判定對焦與閃光遠近。";
        return new Assessment(title,detail,caution,focus,motion,diff,a,t,flashMax,auto);
    }
    public static List<Plan> plans(Reading r){
        List<Plan> result=new ArrayList<>();Assessment a=assess(r);Profile p=r.profile;
        if(Boolean.FALSE.equals(a.focusOK))result.add(new Plan("distance","後退一點，再點選主體",
                "讓主體落在相機可對焦的範圍內，再次點選畫面確認距離。",null));
        Pair pair=bestPair(r);
        if(pair!=null)result.add(new Plan("settings","試試這組光圈與快門",
                "f/"+one(pair.aperture)+" · "+shutter(pair.shutter)+"。"
                        +(pair.shutter>referenceShutter(r)?"快門仍偏慢，請穩住相機或增加光線。":"請先在相機上調整，再重新測光。"),pair));
        boolean dim=a.exposureDifference!=null?a.exposureDifference< -1:r.ev100<8;
        if(dim&&!Boolean.FALSE.equals(p.hasFlash))result.add(new Plan("flash","可以考慮開啟閃光",
                a.flashMax==null||r.distance==null?
                        "若相機支援閃光，先確認主體在說明書的有效距離內。遠方背景仍可能偏暗。":
                        "直打模型估算上限約 "+one(a.flashMax)+" 公尺；請同時留意主體遠近。",null));
        if(a.exposureDifference!=null&&a.exposureDifference>1)
            result.add(new Plan("shade","移到光線柔和一點的地方","避開過亮的直射光，保留主體亮部，再重新測光。",null));
        else result.add(new Plan("light",dim?"靠近窗邊或現有光源":"換個位置，看看光線",
                "讓主體靠近可用的自然光，再重新測量確認變化。移動不代表光線一定改善。",null));
        if(p.kind==Kind.MANUAL&&pair==null)
            result.add(new Plan("manual-tip","可開大光圈，並留意快門",
                    "若想保留較多現場光，可試較小的 f 值。填寫鏡頭與快門可用刻度後，才能提供具體組合。",null));
        if(r.iso==null)result.add(new Plan("film-info","先看看底片盒上的 ISO",
                QuickExposure.isQuick(r)?"找到底片盒上的數字後，點這裡選擇試算 ISO。":"找找 100、200、400、800 等數字，之後從相機資料的選單選入即可。",null));
        return result;
    }
    public static boolean comparable(Reading before,Reading after){
        return before!=null&&after!=null&&before.signature.equals(after.signature)
                &&java.util.Objects.equals(before.iso,after.iso)
                &&before.profile.id.equals(after.profile.id)&&before.profile.kind==after.profile.kind;
    }
    public static String one(double v){return String.format(Locale.TAIWAN,"%.1f",v);}
    public static String shutter(double t){
        if(!positive(t))throw new IllegalArgumentException("快門秒數無效。");
        double denominator=1/t;
        if(t<1&&(denominator>=10||Math.abs(denominator-Math.rint(denominator))<1e-7))
            return "1/"+Math.max(1,Math.round(denominator))+" 秒";
        return java.math.BigDecimal.valueOf(t).stripTrailingZeros().toPlainString()+" 秒";
    }
    private static double[] checkedSteps(double[] values,Double min,Double max){
        if(values==null)return new double[0];
        if(values.length>40)throw new IllegalArgumentException("可用刻度最多 40 個。");
        double[] copy=values.clone();
        for(double v:copy)if(!positive(v)||min!=null&&v<min||max!=null&&v>max)
            throw new IllegalArgumentException("請核對可用刻度範圍。");
        return Arrays.stream(copy).distinct().sorted().toArray();
    }
    private static boolean contains(double[] values,double v){
        for(double n:values)if(Math.abs(n-v)<=Math.max(1e-10,Math.abs(v)*1e-8))return true;
        return false;
    }
    private static double[] defaultApertures(double min,double max){
        return java.util.stream.DoubleStream.concat(Arrays.stream(
                new double[]{1,1.2,1.4,1.8,2,2.8,4,5.6,8,11,16,22,32,45,64}),
                Arrays.stream(new double[]{min,max})).filter(v->v>=min&&v<=max).distinct().toArray();
    }
    private static double[] defaultShutters(double min,double max){
        return java.util.stream.DoubleStream.concat(Arrays.stream(
                new double[]{30,15,8,4,2,1,.5,.25,.125,1.0/15,1.0/30,1.0/60,1.0/125,
                        1.0/250,1.0/500,1.0/1000,1.0/2000,1.0/4000,1.0/8000}),
                Arrays.stream(new double[]{min,max})).filter(v->v>=min&&v<=max).distinct().toArray();
    }
}



