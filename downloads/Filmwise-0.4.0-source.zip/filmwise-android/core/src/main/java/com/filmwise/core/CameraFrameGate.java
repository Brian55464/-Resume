package com.filmwise.core;

/** AR rendering can repeat a camera frame; a repeated frame cannot renew a light reading. */
public final class CameraFrameGate {
    private long lastTimestamp;
    private long lastFrameAt;
    private long sampledTimestamp;
    public boolean observe(long timestamp,long now){
        if(timestamp<=0||now<0||timestamp<=lastTimestamp)return false;
        lastTimestamp=timestamp;lastFrameAt=now;return true;
    }
    public boolean fresh(long now){
        return lastTimestamp>0&&now>=lastFrameAt&&now-lastFrameAt<=1500;
    }
    public boolean takeSample(long now){
        if(!fresh(now)||sampledTimestamp==lastTimestamp)return false;
        sampledTimestamp=lastTimestamp;return true;
    }
}
