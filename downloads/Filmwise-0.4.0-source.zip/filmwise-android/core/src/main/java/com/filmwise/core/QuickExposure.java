package com.filmwise.core;

import java.util.ArrayList;
import java.util.List;
import com.filmwise.core.ExposureEngine.Intent;
import com.filmwise.core.ExposureEngine.Profile;
import com.filmwise.core.ExposureEngine.Kind;
import com.filmwise.core.ExposureEngine.Reading;

/** General exposure references; these stops never describe an unknown camera's capabilities. */
public final class QuickExposure {
    public static final String PROFILE_ID="quick-meter-v1";
    public static final int DEFAULT_REFERENCE_ISO=400;
    private static final double[] SHUTTERS={1.0/8000,1.0/4000,1.0/2000,1.0/1000,1.0/500,
        1.0/250,1.0/125,1.0/60,1.0/30,1.0/15,1.0/8,.25,.5,1,2,4,8,15,30};
    private QuickExposure() {}
    public static Profile profile(){
        return Profile.partial(PROFILE_ID,Kind.AUTO,"直接測光・通用參考",null,null,null,null,
            null,null,null,null,null,null,null,null);
    }
    public static boolean isQuick(Reading reading){return reading!=null&&PROFILE_ID.equals(reading.profile.id);}
    public static final class Option {
        public final double aperture,shutter,difference;
        public final boolean slow;
        private Option(double a,double t,double difference,Intent intent){
            this.aperture=a;this.shutter=t;this.difference=difference;
            this.slow=t>(intent==Intent.MOVING?1.0/250:1.0/60);
        }
    }
    public static List<Option> suggest(double ev100,Integer referenceISO,Intent intent){
        if(!Double.isFinite(ev100)||ev100< -32||ev100>40||intent==null)
            throw new IllegalArgumentException("測光參考資料無效。");
        InputLimits.iso(referenceISO);
        int iso=referenceISO==null?DEFAULT_REFERENCE_ISO:referenceISO;
        double[] apertures=switch(intent){
            case STILL -> new double[]{2.8,4,5.6,8,2,1.4,11,16,22};
            case MOVING -> new double[]{2,2.8,4,1.4,5.6,8,11,16,22};
            case LANDSCAPE -> new double[]{8,11,16,5.6,4,2.8,2,1.4,22};
        };
        List<Option> result=new ArrayList<>();
        for(double aperture:apertures){
            double bestTime=0,bestError=Double.POSITIVE_INFINITY,bestDifference=0;
            for(double shutter:SHUTTERS){
                double difference=ev100-ExposureEngine.exposureEV(aperture,shutter,iso);
                if(Math.abs(difference)<bestError){bestError=Math.abs(difference);bestTime=shutter;bestDifference=difference;}
            }
            // Do not turn an out-of-range exposure into an apparently valid clamped setting.
            if(bestError<=.5+1e-9)result.add(new Option(aperture,bestTime,bestDifference,intent));
            if(result.size()==3)break;
        }
        return java.util.Collections.unmodifiableList(result);
    }
}
