package com.filmwise.core;

/** An estimate always carries its origin and expires after the selected point may have changed. */
public final class DistanceEstimate {
    public final Double meters;
    public final String source, message;
    public final long measuredAt;
    public DistanceEstimate(Double meters,String source,String message,long measuredAt){
        if(meters!=null&&(!Double.isFinite(meters)||meters<.2||meters>15))
            throw new IllegalArgumentException("距離不在可估算範圍。");
        this.meters=meters;this.source=source;this.message=message;this.measuredAt=measuredAt;
    }
    public boolean fresh(long now){return meters!=null&&now>=measuredAt&&now-measuredAt<=10000;}
    public static Double fromFocus(Float diopters,Integer calibration,boolean focused){
        if(!focused||diopters==null||!Float.isFinite(diopters)||diopters<=0
                ||calibration==null||calibration<1||calibration>2)return null;
        double value=1.0/diopters;
        return value>=.2&&value<=15?value:null;
    }
    public static DistanceEstimate unknown(String message){
        return new DistanceEstimate(null,"暫時無法估距",message,0);
    }
}
