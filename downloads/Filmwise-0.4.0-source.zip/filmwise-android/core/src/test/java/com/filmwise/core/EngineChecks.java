package com.filmwise.core;

import com.filmwise.core.ExposureEngine.*;

public final class EngineChecks {
    private static int count;
    private static void check(boolean valid,String message) {
        count++; if(!valid) throw new AssertionError(message);
    }
    private static void near(double a,double b) { check(Math.abs(a-b)<1e-7,a+" != "+b); }
    private static Profile profile(Kind kind,double gn) {
        return new Profile(kind,"Test camera",5.6,1.0/125,2,16,1.0/1000,1,50,.6,gn,true);
    }
    private static Reading reading(Kind kind,double ev,double distance,boolean flash,double gn) {
        return new Reading(profile(kind,gn),400,ev,distance,Intent.STILL,flash,"test","same-source",1);
    }
    public static void main(String[] args) {
        near(ExposureEngine.exposureEV(8,1.0/125,200),ExposureEngine.exposureEV(8,1.0/125,100)-1);
        near(ExposureEngine.exposureEV(8,1.0/60,100),ExposureEngine.exposureEV(8,1.0/120,100)-1);
        near(ExposureEngine.exposureEV(8,1.0/125,100),ExposureEngine.exposureEV(4,1.0/125,100)+2);
        check(ExposureEngine.assess(reading(Kind.FIXED,4,2,false,0)).caution,"Low light must warn.");
        check(!ExposureEngine.assess(reading(Kind.FIXED,4,.3,true,20)).focusOK,"Flash cannot fix focus.");
        check(ExposureEngine.assess(reading(Kind.AUTO,4,2,false,20)).actualShutter==null,"Auto shutter unknown.");
        check(ExposureEngine.assess(reading(Kind.AUTO,4,2,false,20)).actualAperture==null,"Auto aperture unknown.");
        check(ExposureEngine.assess(reading(Kind.FIXED,4,2,true,0)).flashMax==null,"Unknown GN must stay unknown.");
        check(ExposureEngine.assess(reading(Kind.FIXED,4,30,true,10)).caution,"Beyond flash reach must warn.");
        for(Kind kind:Kind.values()) {
            boolean settings=ExposureEngine.plans(reading(kind,7,2,false,0)).stream().anyMatch(p->p.id.equals("settings"));
            check(settings==(kind==Kind.MANUAL),"Only manual cameras get settings plans.");
        }
        for(double ev:new double[]{-1,3,7,10,15,20}) {
            Reading r=reading(Kind.MANUAL,ev,2,false,0);
            Pair pair=ExposureEngine.bestPair(r);
            check(pair!=null&&pair.aperture>=2&&pair.aperture<=16,"Supported apertures only.");
            check(pair.shutter>=1.0/1000&&pair.shutter<=1,"Supported shutters only.");
        }
        Reading before=reading(Kind.FIXED,7,2,false,0);
        Reading after=reading(Kind.FIXED,9,2,false,0);
        near(ExposureEngine.assess(after).exposureDifference-ExposureEngine.assess(before).exposureDifference,2);
        near(after.ev100-before.ev100,2);
        check(ExposureEngine.comparable(before,after),"Same source comparable.");
        Reading changed=new Reading(before.profile,400,9,2,Intent.STILL,false,"manual","different",1);
        check(!ExposureEngine.comparable(before,changed),"Different sources cannot imply improvement.");
        MeterEstimator estimator=new MeterEstimator();
        check(estimator.accept(null,100,2f,100,2,1000).ev100==null,"Missing metadata rejected.");
        check(estimator.accept(10_000_000L,100,2f,100,1,1100).ev100==null,"Searching AE rejected.");
        check(estimator.accept(10_000_000L,100,2f,100,4,1200).ev100==null,"Flash-required AE rejected.");
        MeterEstimator.Sample sample=null;
        for(int i=0;i<6;i++) sample=estimator.accept(10_000_000L,100,2f,100,2,2000+i*200);
        check(sample.ev100!=null,"Stable complete metadata accepted.");
        near(sample.ev100,ExposureEngine.exposureEV(2,.01,100));
        check(!sample.fresh(5000),"Stale samples cannot be captured.");
        MeterEstimator boosted=new MeterEstimator();
        MeterEstimator.Sample b=null;
        for(int i=0;i<6;i++) b=boosted.accept(10_000_000L,100,2f,200,2,2000+i*200);
        near(b.ev100,sample.ev100-1);
        check(estimator.accept(10_000_000L,100,2f,100,2,8000).ev100==null,"Resume must collect new samples.");
        Profile vintage=new Profile(Kind.MANUAL,"Vintage",4,1.0/100,4,8,1.0/200,1.0/25,
                50,1,0,false,new double[]{4,8},new double[]{1.0/25,1.0/50,1.0/100,1.0/200});
        for(double ev:new double[]{7,10,13,16}) {
            Pair pair=ExposureEngine.bestPair(new Reading(vintage,400,ev,2,Intent.STILL,false,"test","same",1));
            check(pair.shutter==1.0/25||pair.shutter==1.0/50||pair.shutter==1.0/100||pair.shutter==1.0/200,
                    "Recommendation must respect actual dial stops.");
        }
        for(Kind kind:Kind.values()){
            Profile unknown=Profile.partial("unknown-"+kind,kind,"Unknown",null,null,null,null,null,null,
                    null,null,null,null,new double[0],new double[0]);
            Reading u=new Reading(unknown,null,5.0,null,Intent.STILL,false,"test","same",1,"unknown");
            Assessment ua=ExposureEngine.assess(u);
            check(ua.actualAperture==null&&ua.actualShutter==null,"Unknown settings must remain null.");
            check(ua.exposureDifference==null&&ua.focusOK==null&&ua.motionRisk==null,"No verdict from missing facts.");
            check(ua.flashMax==null,"No invented flash distance.");
            check(ExposureEngine.bestPair(u)==null,"No invented dial stops or ISO.");
            check(!ExposureEngine.plans(u).isEmpty(),"Unknown specs still get helpful advice.");
            check(ExposureEngine.assess(new Reading(unknown,400,5.0,null,Intent.STILL,true,"test","same",1,"unknown")).caution,
                    "Unknown flash range must be conditional.");
        }
        Profile one=Profile.partial("one",Kind.MANUAL,"Same name",null,null,4.0,8.0,1.0/100,1.0/25,
                null,null,null,false,new double[]{4,8},new double[]{1.0/25,1.0/100});
        Profile two=Profile.partial("two",Kind.MANUAL,"Same name",null,null,null,null,null,null,
                null,null,null,false,null,null);
        Reading r1=new Reading(one,400,10.0,null,Intent.STILL,false,"test","same",1,"unknown");
        Reading r2=new Reading(two,400,10.0,null,Intent.STILL,false,"test","same",1,"unknown");
        check(!ExposureEngine.comparable(r1,r2),"Same-name cameras with different IDs are not comparable.");
        check(ExposureEngine.plans(r1).stream().noneMatch(p->p.id.equals("flash")),"No flash plan on camera without flash.");
        Pair exact=ExposureEngine.bestPair(r1);
        check(exact!=null&&(exact.aperture==4||exact.aperture==8),"Explicit aperture stops only.");
        check(exact.shutter==1.0/25||exact.shutter==1.0/100,"Explicit shutter stops only.");
        Reading noISO=new Reading(one,null,10.0,null,Intent.STILL,false,"test","same",1,"unknown");
        check(ExposureEngine.bestPair(noISO)==null,"Unknown ISO prevents exact pair calculation.");
        check(!ExposureEngine.comparable(r1,noISO),"Unknown ISO not equivalent to known ISO.");
        check(DistanceEstimate.fromFocus(null,1,true)==null,"Missing focus distance stays unknown.");
        check(DistanceEstimate.fromFocus(2f,0,true)==null,"Uncalibrated lens data not converted.");
        check(DistanceEstimate.fromFocus(0f,2,true)==null,"Infinity is not a finite subject distance.");
        check(DistanceEstimate.fromFocus(Float.NaN,2,true)==null,"Invalid focus data rejected.");
        check(DistanceEstimate.fromFocus(2f,2,false)==null,"Unsuccessful focus cannot provide distance.");
        near(DistanceEstimate.fromFocus(2f,1,true),.5);
        near(DistanceEstimate.fromFocus(2f,2,true),.5);
        DistanceEstimate d=new DistanceEstimate(.5,"focus","test",1000);
        check(d.fresh(11000),"Distance valid for bounded freshness window.");
        check(!d.fresh(11001)&&!d.fresh(999),"Stale or future distance rejected.");
        check(!DistanceEstimate.unknown("test").fresh(1000),"Unknown distance is never fresh.");
        boolean invalid=false;
        try{Profile.partial("bad",Kind.FIXED,"Bad",-1.0,null,null,null,null,null,null,null,null,null,null,null);}
        catch(IllegalArgumentException expected){invalid=true;}
        check(invalid,"Invalid negative camera values rejected.");
        CameraFrameGate frameGate=new CameraFrameGate();
        check(!frameGate.observe(0,1000),"An empty AR frame is not a camera observation.");
        check(frameGate.observe(100,1000)&&frameGate.takeSample(1000),"New camera frame can be sampled.");
        check(!frameGate.takeSample(1100),"A frame is only sampled once.");
        check(!frameGate.observe(100,2400),"Rendering the same frame does not renew capture time.");
        check(!frameGate.fresh(2501),"Repeated old frame must become stale.");
        check(!frameGate.observe(99,2600),"Out-of-order camera frames rejected.");
        check(frameGate.observe(101,2700)&&frameGate.takeSample(2700),"New frame restores eligibility.");
        check(!frameGate.fresh(2699),"Future camera time is not a fresh reading.");
        MeterEstimator unstable=new MeterEstimator();
        MeterEstimator.Sample varying=null;
        for(int i=0;i<8;i++)varying=unstable.accept(i%2==0?10_000_000L:20_000_000L,100,2f,100,2,10000+i*200);
        check(varying.ev100==null,"A moving exposure window cannot be called stable.");
        for(int i=0;i<6;i++)varying=unstable.accept(10_000_000L,100,2f,100,2,12000+i*200);
        check(varying.ev100!=null,"Stable new frames recover from a changing scene.");
        check(!varying.fresh(varying.monotonicMillis-1),"Future-dated samples rejected.");
        near(ExposureEngine.exposureEV(16,1.0/125,100),ExposureEngine.log2(32000));
        check(unstable.accept(10_000_000L,100,2f,0,2,15000).ev100==null,"Invalid post-RAW gain rejected.");
        String[] hostileNames={"x".repeat(101),"name\nspoof","a\u202Etxt"};
        for(String name:hostileNames){
            boolean rejected=false;
            try{Profile.partial("id",Kind.FIXED,name,null,null,null,null,null,null,null,null,null,null,null,null);}
            catch(IllegalArgumentException expected){rejected=true;}
            check(rejected,"Oversized/control/bidi camera names rejected.");
        }
        for(Double bad:new Double[]{Double.NaN,Double.POSITIVE_INFINITY,1e300,0.0}){
            boolean rejected=false;
            try{Profile.partial("id",Kind.FIXED,"Camera",bad,null,null,null,null,null,null,null,null,null,null,null);}
            catch(IllegalArgumentException expected){rejected=true;}
            check(rejected,"Nonfinite or out-of-range optics rejected.");
        }
        boolean oversized=false;
        try{Profile.partial("id",Kind.MANUAL,"Camera",null,null,null,null,null,null,null,null,null,null,new double[65],null);}
        catch(IllegalArgumentException expected){oversized=true;}
        check(oversized,"Unbounded dial arrays rejected before pair search.");
        boolean badIso=false;
        try{new Reading(one,Integer.MAX_VALUE,10.0,null,Intent.STILL,false,"test","same",1,"unknown");}
        catch(IllegalArgumentException expected){badIso=true;}
        check(badIso,"Out-of-range stored ISO rejected.");
        InputLimits.range(null,.1,256,"光圈");
        check(true,"Unknown optics remain allowed.");
        InputLimits.text("我的相機 📷",100,"相機名稱");
        check(true,"Traditional Chinese and ordinary emoji remain supported.");
        check(!new MeterEstimator.Sample(Double.NaN,"invalid",1000).fresh(1100),"NaN sample is never ready.");
        check(!new MeterEstimator.Sample(Double.POSITIVE_INFINITY,"invalid",1000).fresh(1100),"Infinite sample is never ready.");
        MeterEstimator outliers=new MeterEstimator();
        MeterEstimator.Sample extreme=null;
        for(int i=0;i<6;i++)extreme=outliers.accept(1L,1,Float.MAX_VALUE,100,2,20000+i*200);
        check(extreme.ev100==null,"Finite but impossible bright sensor data rejected.");
        for(int i=0;i<6;i++)extreme=outliers.accept(Long.MAX_VALUE,Integer.MAX_VALUE,.1f,Integer.MAX_VALUE,2,22000+i*200);
        check(extreme.ev100==null,"Finite but impossible dark sensor data rejected.");
        check(outliers.accept(10000000L,100,2f,100,2,24000).ev100==null,"Sensor outliers cannot seed a stable measurement window.");
        java.util.List<QuickExposure.Option> quick=QuickExposure.suggest(9.0,400,Intent.STILL);
        check(quick.size()==3,"Direct metering supplies three references without a saved camera.");
        near(quick.get(0).aperture,2.8);near(quick.get(0).shutter,1.0/250);
        java.util.List<QuickExposure.Option> assumed=QuickExposure.suggest(9.0,null,Intent.STILL);
        near(assumed.get(0).shutter,quick.get(0).shutter);
        check(QuickExposure.profile().aperture==null&&QuickExposure.profile().shutter==null,
            "Reference stops never become facts about an unknown camera.");
        check(QuickExposure.profile().getApertures().length==0&&QuickExposure.profile().getShutters().length==0,
            "Reference mode does not invent camera dial capabilities.");
        near(QuickExposure.suggest(9.0,800,Intent.STILL).get(0).shutter,1.0/500);
        near(QuickExposure.suggest(9.0,100,Intent.STILL).get(1).shutter,1.0/30);
        near(QuickExposure.suggest(9.0,400,Intent.STILL).get(1).shutter,1.0/125);
        check(QuickExposure.suggest(2.0,100,Intent.STILL).stream().allMatch(o->o.slow),"Low-light slow shutters carry a warning.");
        near(QuickExposure.suggest(10.0,400,Intent.LANDSCAPE).get(0).aperture,8);
        check(QuickExposure.suggest(40.0,400,Intent.STILL).isEmpty(),"Extreme bright scene not clamped into a usable pair.");
        check(QuickExposure.suggest(-32.0,400,Intent.STILL).isEmpty(),"Extreme dark scene not clamped into a usable pair.");
        boolean invalidReference=false;
        try{QuickExposure.suggest(Double.NaN,400,Intent.STILL);}catch(IllegalArgumentException expected){invalidReference=true;}
        check(invalidReference,"Nonfinite direct metering rejected.");
        boolean invalidReferenceISO=false;
        try{QuickExposure.suggest(9.0,0,Intent.STILL);}catch(IllegalArgumentException expected){invalidReferenceISO=true;}
        check(invalidReferenceISO,"Zero is not an unknown ISO.");
        for(double ev:new double[]{-6,0,4,7,9,12,15,20,24})for(int iso:new int[]{100,400,1600}){
            check(QuickExposure.suggest(ev,iso,Intent.STILL).stream().allMatch(o->Double.isFinite(o.shutter)&&
                Math.abs(ev-ExposureEngine.exposureEV(o.aperture,o.shutter,iso))<=.5000001),
                "All references stay within half a stop of requested EV.");
        }
        System.out.println("PASS: "+count+" checks for exposure, profiles, flash, comparability, stability and stale readings.");
    }
}


